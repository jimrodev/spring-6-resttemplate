package com.santander.scib.creame.excesses.infrastructure.kafka.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.CommonLoggingErrorHandler;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Configuration class for Kafka consumers.
 * This class creates beans for Kafka topics, ConsumerFactory objects, and KafkaListenerContainerFactory objects.
 *
 * @param <K> the type of the Kafka message key
 * @param <V> the type of the Kafka message value
 */
@Configuration
@ConditionalOnExpression(
    "(" +
        "T(org.springframework.boot.context.properties.bind.Binder).get(environment)" +
        ".bind('app.infrastructure.kafka', T(java.util.Map)).orElse(null)?.size()?: 0" +
    ") > 0 and '${app.infrastructure.kafka.enabled:true}' == 'true'"
)
@ConfigurationProperties(prefix = "app.infrastructure.kafka")
@Getter
@Setter
public class KafkaConsumerConfig<K, V> {

    private Map<String, List<String>> topics;

    private Map<String, KafkaConsumerConfigData> consumers;

    /**
     * Creates a map of Kafka topics based on the application's configuration.
     *
     * @return a map of topic names to topic arrays
     */
    @Bean
    public Map<String, String[]> kafkaTopics() {
        Map<String, String[]> topicMap = new HashMap<>();
        topics.forEach((key, value) -> topicMap.put(key, value.toArray(new String[0])));
        return topicMap;
    }

    /**
     * Creates a map of ConsumerFactory objects based on the application's Kafka consumers.
     *
     * @return a map of consumer names to ConsumerFactory objects
     */
    @Bean
    public Map<String, ConsumerFactory<K, V>> consumerFactories() {
        Map<String, ConsumerFactory<K, V>> consumerFactories = new HashMap<>();
        consumers.forEach(
            (key, value) -> {
                Map<String, Object> configurations = value.getConfigurations().entrySet().stream().collect(
                    HashMap::new,
                    (m, v) -> m.put(String.valueOf(v.getKey()), v.getValue()),
                    HashMap::putAll
                );
                consumerFactories.put(key, new DefaultKafkaConsumerFactory<>(configurations));
            }
        );
        return consumerFactories;
    }

    /**
     * Creates a map of KafkaListenerContainerFactory objects based on the application's ConsumerFactory objects.
     *
     * @return a map of consumer names to KafkaListenerContainerFactory objects
     */
    @Bean
    public Map<String, KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<K, V>>>
        kafkaListenerContainerFactories() {

        Map<String, KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<K, V>>> factories =
            new HashMap<>();

        consumerFactories().forEach(
            (key, value) -> {
                ConcurrentKafkaListenerContainerFactory<K, V> factory = new ConcurrentKafkaListenerContainerFactory<>();
                factory.setConsumerFactory(value);
                boolean batchListener = consumers.get(key).getBatchListener();
                factory.setBatchListener(batchListener);
                if (batchListener) {
                    factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.BATCH);
                    factory.setCommonErrorHandler(new CommonLoggingErrorHandler());
                } else {
                    factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.RECORD);
                }
                factory.setConcurrency(consumers.get(key).getConcurrency());
                factory.setAutoStartup(consumers.get(key).getAutoStartup());
                factory.getContainerProperties().setPollTimeout(consumers.get(key).getPollTimeoutMs());
                factories.put(key, factory);
            }
        );

        return factories;
    }

}
