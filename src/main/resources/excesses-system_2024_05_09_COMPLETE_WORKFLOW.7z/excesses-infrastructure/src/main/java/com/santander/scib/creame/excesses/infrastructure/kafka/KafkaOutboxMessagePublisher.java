package com.santander.scib.creame.excesses.infrastructure.kafka;

import com.google.common.reflect.TypeToken;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.OutboxBehavior;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.helper.ContextHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.avro.specific.SpecificRecordBase;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import java.util.function.BiConsumer;
import java.util.function.Function;

@Slf4j
public abstract class KafkaOutboxMessagePublisher<T , U extends SpecificRecordBase, V extends OutboxBehavior>  {

    private final KafkaProducer<String, U> kafkaProducer;

    private final KafkaProducerHelper kafkaProducerHelper;


    public KafkaOutboxMessagePublisher(KafkaProducer<String, U> kafkaProducer,
                                       KafkaProducerHelper kafkaProducerHelper) {
        this.kafkaProducer = kafkaProducer;
        this.kafkaProducerHelper = kafkaProducerHelper;
    }

    public void publish(V outboxMessage,
                        BiConsumer<V, OutboxStatus> outboxCallback,
                        Function<T, U> mapper,
                        String requestTopicName)
    {
        T request = kafkaProducerHelper.deserializePayload(outboxMessage.getPayload(),
                getType());

        String outboxId = outboxMessage.getOutboxId().toString();
        String messageId = outboxMessage.getMessageId();

        log.info("Received OutboxMessage for message id: {} and outbox id: {}",
                messageId,
                outboxId);

        try {
            U requestAvroModel = mapper.apply(request);

            ContextMessage context = kafkaProducerHelper.deserializePayload(outboxMessage.getContext(),
                                                                            ContextMessage.class);

            Message<U> message = MessageBuilder
                    .withPayload(requestAvroModel)
                    .setHeader(KafkaHeaders.KEY, messageId)
                    .setHeader(KafkaHeaders.TOPIC, requestTopicName)
                    .copyHeaders(ContextHelper.getMessageHeaders(context))
                    .build();

            kafkaProducer.send(message,
                    kafkaProducerHelper.getKafkaCallback(
                            outboxMessage,
                            message,
                            outboxCallback));

            log.info("Request sent to Kafka for message id: {} " +
                            (outboxMessage.getSagaId() == null ? "and outbox id: " + outboxId : "and interchange id: " + outboxMessage.getSagaId().toString()),
                    messageId);

        } catch (Exception e) {
            log.error("Error while sending request to kafka with message id: {} " +
                            (outboxMessage.getSagaId() == null ? "and outbox id: " + outboxId : "and interchange id: " + outboxMessage.getSagaId().toString()) +
                    ". Error: {}",
                    messageId,
                    e.getMessage());
        }
    }

    private Class<T> getType(){
        TypeToken<T> typeToken = new TypeToken<>(getClass()) {};
        return (Class<T>)typeToken.getRawType();
    }
}
