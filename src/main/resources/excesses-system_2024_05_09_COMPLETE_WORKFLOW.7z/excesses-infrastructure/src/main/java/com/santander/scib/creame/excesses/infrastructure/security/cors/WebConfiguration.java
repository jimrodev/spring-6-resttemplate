package com.santander.scib.creame.excesses.infrastructure.security.cors;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.reactive.config.CorsRegistry;
import org.springframework.web.reactive.config.WebFluxConfigurer;

import java.util.Properties;

/**
 * The Web configuration manages web endpoint permissions.
 */
@Configuration
@ConditionalOnProperty(value="app.infrastructure.endpoints.mode", havingValue = "local")
@Getter
public class WebConfiguration implements WebFluxConfigurer {

    @Value("#{parameters.?[key.startsWith('cors')]}")
    private Properties configurations;

    /**
     * Creates a LinkedMultiValueMap containing CORS headers.
     * The headers are populated with values from the application's configurations.
     * If a specific configuration is not found, a default value is used.
     *
     * @return a LinkedMultiValueMap with CORS headers and their corresponding values.
     */
    @Bean("corsHeaders")
    public LinkedMultiValueMap<String, String> corsHeaders() {
        LinkedMultiValueMap<String, String> corsHeaders = new LinkedMultiValueMap<>();
        corsHeaders.add(
            HttpHeaders.ACCESS_CONTROL_ALLOW_ORIGIN,
            configurations.getProperty("cors.allowed-origins", "http://localhost:5173")
        );
        corsHeaders.add(
            HttpHeaders.ACCESS_CONTROL_ALLOW_METHODS,
            configurations.getProperty("cors.allowed-methods", "*")
        );
        corsHeaders.add(
            HttpHeaders.ACCESS_CONTROL_ALLOW_HEADERS,
            configurations.getProperty("cors.allowed-headers", "*")
        );
        corsHeaders.add(
            HttpHeaders.ACCESS_CONTROL_ALLOW_CREDENTIALS,
            configurations.getProperty("cors.allowed-credentials", "true")
        );
        corsHeaders.add(
            HttpHeaders.ACCESS_CONTROL_MAX_AGE,
            configurations.getProperty("cors.max-age", "3600")
        );
        return corsHeaders;
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**")
            .allowedOrigins(configurations.getProperty("cors.allowed-origins", "http://localhost:5173"))
            .allowedMethods(configurations.getProperty("cors.allowed-methods", "*"))
            .allowedHeaders(configurations.getProperty("cors.allowed-headers", "*"))
            .allowCredentials(
                Boolean.parseBoolean(configurations.getProperty("cors.allowed-credentials", "true"))
            )
            .maxAge(Long.parseLong(configurations.getProperty("cors.max-age", "3600")));
    }

}
