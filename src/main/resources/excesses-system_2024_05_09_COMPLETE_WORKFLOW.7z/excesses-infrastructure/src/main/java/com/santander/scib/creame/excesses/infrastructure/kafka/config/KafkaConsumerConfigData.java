package com.santander.scib.creame.excesses.infrastructure.kafka.config;

import lombok.Data;

import java.util.Properties;

/**
 * Configuration data for Kafka consumers.
 */
@Data
public class KafkaConsumerConfigData {

    @SuppressWarnings("java:S1068")
    private Boolean batchListener;

    @SuppressWarnings("java:S1068")
    private Boolean autoStartup;

    @SuppressWarnings("java:S1068")
    private Integer concurrency;

    @SuppressWarnings("java:S1068")
    private Long pollTimeoutMs;

    @SuppressWarnings("java:S1068")
    private Properties configurations;

}
