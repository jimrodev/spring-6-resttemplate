package com.santander.scib.creame.excesses.infrastructure.kafka;

import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.header.Header;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.serializer.DeserializationException;
import org.springframework.kafka.support.serializer.SerializationUtils;
import org.springframework.messaging.Message;

import java.util.ArrayList;
import java.util.List;

/**
 * Helper class for Kafka consumers.
 * This class provides methods for sanitizing messages received from Kafka.
 */
@Slf4j
public class KafkaConsumerHelper {

    private KafkaConsumerHelper() {
        // Private constructor to hide the implicit public one
    }

    /**
     * Sanitizes a list of messages received from Kafka.
     * This method filters out messages that could not be deserialized and logs an error for each of them.
     *
     * @param messages the list of received messages
     * @param <K> the type of the message
     * @return a list of messages that were successfully deserialized
     */
    public static <K> List<Message<K>> sanitizedMessages(List<Message<K>> messages) {
        List<Message<K>> sanitizedMessages = new ArrayList<>();
        messages.forEach(message -> {
            if (message.getHeaders().get(SerializationUtils.VALUE_DESERIALIZER_EXCEPTION_HEADER) != null) {
                DeserializationException deserEx = SerializationUtils.byteArrayToDeserializationException(
                    null,
                    (Header) message.getHeaders().get(SerializationUtils.VALUE_DESERIALIZER_EXCEPTION_HEADER)
                );
                if (deserEx != null) {
                    log.error(
                        String.format(
                            "WHEN TRY TO DESERIALIZE Topic: %s Partition: %s Offset: %s - WRONG PROCESS: ",
                            message.getHeaders().get(KafkaHeaders.RECEIVED_TOPIC),
                            message.getHeaders().get(KafkaHeaders.RECEIVED_PARTITION),
                            message.getHeaders().get(KafkaHeaders.OFFSET)
                        ),
                        deserEx);
                }
            } else {
                sanitizedMessages.add(message);
            }
        });
        return sanitizedMessages;
    }

}
