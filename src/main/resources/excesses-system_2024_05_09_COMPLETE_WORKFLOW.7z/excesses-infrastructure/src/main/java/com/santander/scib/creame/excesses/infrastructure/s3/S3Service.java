package com.santander.scib.creame.excesses.infrastructure.s3;

import software.amazon.awssdk.core.exception.SdkException;
import software.amazon.awssdk.services.s3.S3Client;

import java.io.IOException;
import java.io.InputStream;

/**
 * Interface for S3 services.
 * This interface provides a method for downloading files from S3.
 */
public interface S3Service {

    /**
     * Downloads a file from S3.
     *
     * @param s3Client the S3 client
     * @param bucketName the name of the bucket
     * @param keyName the name of the key
     * @return the input stream of the downloaded file
     * @throws IOException if an I/O error occurs
     * @throws SdkException if an error occurs in the SDK
     */
    InputStream downloadFile(
        S3Client s3Client,
        String bucketName,
        final String keyName
    ) throws IOException, SdkException;

}
