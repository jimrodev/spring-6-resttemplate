package com.santander.scib.creame.excesses.infrastructure.kafka;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import org.springframework.messaging.MessageHeaders;

import java.util.UUID;

public class KafkaContextHelper {
    public static ContextMessage getContextMessage(MessageHeaders headers){
        ContextMessage context = ContextMessage.builder().build();

        // EME - Excess Message Engine Properties

        // EME.messageId: Is the unique identifier of the message in the system (Excess primary Key)                                        .build();
        if(headers.get("messageId")!=null){
            context.setMessageId((String)headers.get("messageId"));
        }
        // EME.interchangeId: Defines the unique ID that is used to group the messages that resulted from the same interchange among async services.
        if(headers.get("interchangeId")!=null){
            context.setInterchangeId(UUID.fromString((String)headers.get("interchangeId")));
        }
        // EME.messageType: Specifies the type of the message.
        if(headers.get("messageType")!=null){
            context.setMessageType((String)headers.get("messageType"));
        }
        // EME.eventSource: The source of the event.
        if(headers.get("eventSource")!=null){
            context.setEventSource((String)headers.get("eventSource"));
        }
        // EME.InboundTransportType: Specifies the type of adapter that received this message and submitted it into the system. s3://, https://, file://, kafka://
        if(headers.get("inboundTransportType")!=null){
            context.setInboundTransportType((String)headers.get("inboundTransportType"));
        }
        // EME.InboundTransportLocation: Specifies the location (URI) on which the message was received by the handler.
        if(headers.get("inboundTransportLocation")!=null){
            context.setInboundTransportLocation((String)headers.get("inboundTransportLocation"));
        }
        // EME.OutboundTransportType: Specifies the type of adapter used to send the message. The available adapter types are s3://, https://, file://, kafka://
        if(headers.get("outboundTransportType")!=null){
            context.setOutboundTransportType((String)headers.get("outboundTransportType"));
        }
        // EME.OutboundTransportLocation: Specifies the destination location URI where the message is sent. The URI may contain the adapter prefix, such as http://.
        //                                The adapter prefix is used by the Messaging Engine to determine the type of adapter to use when sending the message.
        if(headers.get("outboundTransportLocation")!=null){
            context.setOutboundTransportLocation((String)headers.get("outboundTransportLocation"));
        }
        // EME.ReceivePortID: Identifies the receive port on which the message was received.
        if(headers.get("receivePortID")!=null){
            context.setReceivePortID((String)headers.get("receivePortID"));
        }
        // EME.SendPortID: Specifies the ID of the send port.
        if(headers.get("sendPortID")!=null){
            context.setSendPortID((String)headers.get("sendPortID"));
        }
        // EME.FailureCode: Error code associated to the current message
        if(headers.get("failureCode")!=null){
            context.setFailureCode((String)headers.get("failureCode"));
        }
        // EME.FailureMessages: Array with the error description
        if(headers.get("failureMessages")!=null){
            context.setFailureMessages((String)headers.get("failureMessages"));
        }
        // EME.BatchId: Identifies the current Batch of messages
        if(headers.get("batchId")!=null){
            context.setBatchId((String)headers.get("batchId"));
        }
        // EME.BatchTotalNumber: Specifies the messages total number in the current batch.
        if(headers.get("batchTotalNumber")!=null){
            context.setBatchTotalNumber((String)headers.get("batchTotalNumber"));
        }
        // EME.BatchSequenceNumber: Specifies the position of the current message in the batch.
        if(headers.get("batchSequenceNumber")!=null){
            context.setBatchSequenceNumber((String)headers.get("batchSequenceNumber"));
        }

        // S3 - S3 Adapter Properties

        // S3.BucketName: The name of the S3 bucket
        if(headers.get("s3BucketName")!=null){
            context.setS3BucketName((String)headers.get("s3BucketName"));
        }
        // S3.s3keyName: The key of the file in the S3 bucket
        if(headers.get("s3keyName")!=null){
            context.setS3keyName((String)headers.get("s3keyName"));
        }
        return context;
    }
}
