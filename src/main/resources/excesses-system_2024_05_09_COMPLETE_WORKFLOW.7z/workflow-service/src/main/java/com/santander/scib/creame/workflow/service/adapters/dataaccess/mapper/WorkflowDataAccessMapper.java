package com.santander.scib.creame.workflow.service.adapters.dataaccess.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.workflow.service.adapters.dataaccess.entity.WorkflowEntity;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import org.springframework.stereotype.Component;

@Component
public class WorkflowDataAccessMapper {

    public WorkflowEntity workflowToWorkflowEntity(Workflow workflow){
        return WorkflowEntity.builder()
                .excessId(workflow.getId().getValue())
                .processTimestamp(workflow.getProcessTimestamp())
                .workflowStatus(workflow.getWorkflowStatus())
                .assignedGroup(workflow.getAssignedGroup())
                .build();
    }

    public Workflow workflowEntityToWorkflow(WorkflowEntity workflowEntity){
        return Workflow.builder()
                .excessId(new ExcessId(workflowEntity.getExcessId()))
                .processTimestamp(workflowEntity.getProcessTimestamp())
                .workflowStatus(workflowEntity.getWorkflowStatus())
                .assignedGroup(workflowEntity.getAssignedGroup())
                .build();
    }
}
