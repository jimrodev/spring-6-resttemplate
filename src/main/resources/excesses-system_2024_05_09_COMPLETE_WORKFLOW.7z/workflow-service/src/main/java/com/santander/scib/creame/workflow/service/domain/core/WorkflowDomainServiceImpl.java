package com.santander.scib.creame.workflow.service.domain.core;

import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowGroup;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import com.santander.scib.creame.workflow.service.domain.core.event.*;
import lombok.extern.slf4j.Slf4j;

import java.time.ZoneId;
import java.time.ZonedDateTime;

@Slf4j
public class WorkflowDomainServiceImpl implements WorkflowDomainService {
    @Override
    public WorkflowEvent assign(Workflow workflow, WorkflowGroup assignedGroup){

        workflow.initialize();
        workflow.assignGroup(assignedGroup);

        log.info("Group {} is assigned for workflow id: {}",
                assignedGroup,
                workflow.getId().getValue());

        return switch (workflow.getWorkflowStatus()){

            case ASSIGNED ->    new AssignedEvent(workflow,
                                                ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
            case FAILED ->      new FailedEvent(workflow,
                                                ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
            case PENDING ->     new AlertEvent(workflow,
                                                ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
        };

    }
}
