package com.santander.scib.creame.workflow.service.domain.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowGroup;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowStatus;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class WorkflowResponse {
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String workflowId;
    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String excessId;
    @NotEmpty(message = "{not.empty}")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    @JsonProperty
    private String processTimestamp;
    @NotNull(message = "{not.null}")
    @JsonProperty
    private WorkflowStatus workflowStatus;
    @NotNull(message = "{not.null}")
    @JsonProperty
    private WorkflowGroup assignedGroup;
}
