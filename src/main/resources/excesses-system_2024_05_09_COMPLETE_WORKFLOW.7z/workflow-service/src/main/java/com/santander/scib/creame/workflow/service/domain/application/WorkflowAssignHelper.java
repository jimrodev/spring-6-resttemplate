package com.santander.scib.creame.workflow.service.domain.application;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowGroup;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.mapper.WorkflowDataMapper;
import com.santander.scib.creame.workflow.service.domain.application.ports.output.repository.WorkflowRepository;
import com.santander.scib.creame.workflow.service.domain.core.WorkflowDomainService;
import com.santander.scib.creame.workflow.service.domain.core.entity.Excess;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;
import com.santander.scib.creame.workflow.service.domain.core.event.WorkflowEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Component
public class WorkflowAssignHelper {

    private final WorkflowDomainService workflowDomainService;
    private final WorkflowRepository workflowRepository;

    private final WorkflowDataMapper workflowDataMapper;

    public WorkflowAssignHelper(WorkflowDomainService workflowDomainService,
                                WorkflowRepository workflowRepository,
                                WorkflowDataMapper workflowDataMapper) {
        this.workflowDomainService = workflowDomainService;
        this.workflowRepository = workflowRepository;
        this.workflowDataMapper = workflowDataMapper;
    }

    @Transactional
    public WorkflowEvent assign(WorkflowRequest workflowRequest){

        Workflow workflow = workflowDataMapper.workflowRequestToWorkflow(workflowRequest);

        WorkflowEvent workflowEvent = workflowDomainService.assign(workflow, WorkflowGroup.GLOBAL_CONTROL);
        workflowRepository.save(workflow);

        return workflowEvent;
    }

    @Transactional(readOnly = true)
    public Optional<Workflow> findById(ExcessId excessId){

        return workflowRepository.findById(excessId);
    }


}
