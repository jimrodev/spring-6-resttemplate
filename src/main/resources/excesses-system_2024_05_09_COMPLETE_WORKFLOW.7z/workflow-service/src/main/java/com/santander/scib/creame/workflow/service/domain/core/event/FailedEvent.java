package com.santander.scib.creame.workflow.service.domain.core.event;

import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;

import java.time.ZonedDateTime;

public class FailedEvent extends WorkflowEvent {
    public FailedEvent(Workflow workflow,
                       ZonedDateTime createdAt) {
        super(workflow, createdAt);
    }
}
