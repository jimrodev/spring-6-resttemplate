package com.santander.scib.creame.workflow.service.domain.core.exception;

import com.santander.scib.creame.excesses.domain.exception.DomainException;

public class WorkflowDomainException extends DomainException {

    public WorkflowDomainException(String message) {
        super(message);
    }

    public WorkflowDomainException(String message, Throwable cause) {
        super(message, cause);
    }
}
