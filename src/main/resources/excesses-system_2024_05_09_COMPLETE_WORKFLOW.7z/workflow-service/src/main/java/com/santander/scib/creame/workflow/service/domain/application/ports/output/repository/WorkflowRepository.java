package com.santander.scib.creame.workflow.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.workflow.service.domain.core.entity.Workflow;

import java.util.List;
import java.util.Optional;

public interface WorkflowRepository {

    Workflow save(Workflow workflow);
    Workflow update(Workflow workflow);
    Optional<Workflow> findById(ExcessId excessId);
}
