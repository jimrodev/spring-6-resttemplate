package com.santander.scib.creame.workflow.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowResponse;
import com.santander.scib.creame.workflow.service.domain.application.ports.input.service.WorkflowApplicationService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Component;

@Component
public class WorkflowApplicationServiceImpl implements WorkflowApplicationService {

    private final WorkflowAssignHandler workflowAssignHandler;

    public WorkflowApplicationServiceImpl(WorkflowAssignHandler workflowAssignHandler) {
        this.workflowAssignHandler = workflowAssignHandler;
    }

    @Override
    public WorkflowResponse assign(@Valid WorkflowRequest workflowRequest, @Valid ContextMessage context) {
        return workflowAssignHandler.assign(workflowRequest, context);
    }
}
