package com.santander.scib.creame.workflow.service.domain.application.ports.input.message.listener;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import jakarta.validation.Valid;

public interface WorkflowRequestMessageListener {
    void assign(@Valid WorkflowRequest workflowRequest, @Valid ContextMessage context);
}
