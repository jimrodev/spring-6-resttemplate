package com.santander.scib.creame.workflow.service.domain.application.ports.input.service;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowResponse;
import jakarta.validation.Valid;

public interface WorkflowApplicationService {
    WorkflowResponse assign(@Valid WorkflowRequest workflowRequest, @Valid ContextMessage context);
}
