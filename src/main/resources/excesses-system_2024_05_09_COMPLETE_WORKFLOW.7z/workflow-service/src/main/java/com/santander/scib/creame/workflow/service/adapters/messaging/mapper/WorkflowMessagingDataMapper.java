package com.santander.scib.creame.workflow.service.adapters.messaging.mapper;

import com.santander.scib.creame.avro.models.*;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.workflow.service.domain.application.dto.WorkflowResponse;
import org.springframework.stereotype.Component;

@Component
public class WorkflowMessagingDataMapper {

    public WorkflowRequest workflowRequestAvroModelToWorkflowRequest(WorkflowRequestAvroModel workflowRequestAvroModel){
        return WorkflowRequest.builder()
                .excessId(workflowRequestAvroModel.getExcessId())
                .processTimestamp(workflowRequestAvroModel.getProcessTimestamp())
                .build();
    }

    public WorkflowResponseAvroModel workflowResponseToWorkflowResponseAvroModel(WorkflowResponse workflowResponse){
        return WorkflowResponseAvroModel.newBuilder()
                .setExcessId(workflowResponse.getExcessId())
                .setProcessTimestamp(workflowResponse.getProcessTimestamp())
                .setWorkflowStatus(WorkflowStatus.valueOf(workflowResponse.getWorkflowStatus().toString()))
                .build();
    }

}
