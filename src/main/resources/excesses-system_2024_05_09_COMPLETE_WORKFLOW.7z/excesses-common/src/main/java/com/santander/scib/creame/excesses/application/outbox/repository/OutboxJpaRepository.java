package com.santander.scib.creame.excesses.application.outbox.repository;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.entity.OutboxEntity;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface OutboxJpaRepository extends JpaRepository<OutboxEntity, UUID> {

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO OutboxEntity " +
            "(outbox_id, " +
            "created_at, " +
            "processed_at, " +
            "event_source, " +
            "event_target, " +
            "message_id, " +
            "payload, " +
            "context, " +
            "outbox_status, " +
            "version)" +
            " VALUES " +
            "(" +
            ":#{#oe.outboxId}," +
            ":#{#oe.createdAt}," +
            ":#{#oe.processedAt}," +
            ":#{#oe.eventSource}," +
            ":#{#oe.eventTarget}," +
            ":#{#oe.messageId}," +
            ":#{#oe.payload}," +
            ":#{#oe.context}," +
            ":#{#oe.outboxStatus.name()}," +
            ":#{#oe.version}" +
            ")", nativeQuery = true)
    public abstract int insert(@Param("oe") OutboxEntity oe);

    @Modifying
    @Transactional
    @Query(value = "UPDATE OutboxEntity oe SET " +
            "oe.createdAt = :#{#oe.createdAt}, " +
            "oe.processedAt = :#{#oe.processedAt}, " +
            "oe.eventSource = :#{#oe.eventSource}, " +
            "oe.eventTarget = :#{#oe.eventTarget}, " +
            "oe.messageId = :#{#oe.messageId}, " +
            "oe.payload = :#{#oe.payload}, " +
            "oe.context = :#{#oe.context}, " +
            "oe.outboxStatus = :#{#oe.outboxStatus.name()}, " +
            "oe.version = :#{#oe.version} " +
            "WHERE " +
            "oe.outboxId = :#{#oe.outboxId}")
    public abstract int update(@Param("oe") OutboxEntity oe);

    @Query(value = "SELECT oe FROM OutboxEntity oe WHERE " +
            "oe.eventSource = :eventSource AND " +
            "oe.eventTarget = :eventTarget AND " +
            "oe.outboxStatus = :outboxStatus ")
    Optional<List<OutboxEntity>> findByOutboxStatus(@Param("eventSource") String eventSource,
                                                    @Param("eventTarget") String eventTarget,
                                                    @Param("outboxStatus") OutboxStatus outboxStatus,
                                                    Pageable pageable);
    @Query(value = "SELECT oe FROM OutboxEntity oe WHERE " +
            "oe.createdAt  >= :createdAt AND " +
            "oe.eventSource = :eventSource AND " +
            "oe.eventTarget = :eventTarget AND " +
            "oe.outboxStatus = :outboxStatus ")
    Optional<List<OutboxEntity>> findByCreatedAtAndOutboxStatus(@Param("eventSource") String eventSource,
                                                                @Param("eventTarget") String eventTarget,
                                                                @Param("createdAt") ZonedDateTime createdAt,
                                                                @Param("outboxStatus") OutboxStatus outboxStatus,
                                                                Pageable pageable);

    @Modifying
    @Query(value = "DELETE OutboxEntity oe WHERE " +
            "oe.eventSource = :eventSource AND " +
            "oe.eventTarget = :eventTarget AND " +
            "oe.outboxStatus = :outboxStatus ")
    int deleteByOutboxStatus(@Param("eventSource") String eventSource,
                             @Param("eventTarget") String eventTarget,
                             @Param("outboxStatus") OutboxStatus outboxStatus);
}
