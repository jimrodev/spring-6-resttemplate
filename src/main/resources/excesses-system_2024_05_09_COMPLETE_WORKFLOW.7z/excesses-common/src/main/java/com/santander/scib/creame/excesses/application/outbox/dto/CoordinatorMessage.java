package com.santander.scib.creame.excesses.application.outbox.dto;

import com.santander.scib.creame.excesses.application.outbox.OutboxBehavior;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.time.ZonedDateTime;
import java.util.UUID;

@Getter
@AllArgsConstructor(staticName = "of")
@Builder
public class CoordinatorMessage implements OutboxBehavior {
    private UUID outboxId;
    private UUID sagaId;
    private ZonedDateTime createdAt;
    private ZonedDateTime processedAt;
    private String eventSource;
    private String eventTarget;
    private String messageId;
    private String payload;
    private String context;
    private OutboxStatus outboxStatus;
    private SagaStatus sagaStatus;
    private int version;
    private boolean isNew;

    public void setProcessedAt(ZonedDateTime processedAt) {
        this.processedAt = processedAt;
    }
    public void setOutboxStatus(OutboxStatus outboxStatus) {
        this.outboxStatus = outboxStatus;
    }
    public void setSagaStatus(SagaStatus sagaStatus) {
        this.sagaStatus = sagaStatus;
    }
    public void setContext(String context) {
        this.context = context;
    }
    public void setNew(boolean aNew) { this.isNew = aNew;}
}
