package com.santander.scib.creame.excesses.domain.entity;

public abstract class AggregateRoot<ID> extends BaseEntity<ID> {
}
