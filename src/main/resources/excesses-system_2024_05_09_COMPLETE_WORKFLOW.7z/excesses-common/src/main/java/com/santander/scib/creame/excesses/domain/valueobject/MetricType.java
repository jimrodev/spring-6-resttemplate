package com.santander.scib.creame.excesses.domain.valueobject;

public enum MetricType {
    RC(0), CR(1), ST(2);

    private final Integer metricType;
    MetricType(Integer metricType){
        this.metricType = metricType;
    }
    public Integer getMetricType(){
        return metricType;
    }
}
