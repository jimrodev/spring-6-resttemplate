package com.santander.scib.creame.excesses.application.saga;

public interface SagaStep<T,U> {
    void process(T data, U context);
    void compensation(T data, U context);
}