package com.santander.scib.creame.excesses.application.outbox;

/**
 * Interface for Spool Schedulers.
 * This interface provides methods for process and clear the spool table.
 */
public interface SpoolScheduler {
    /**
     * Processes a batch of messages from the Spool table.
     */
    void process();
    /**
     * Clear the Spool table.
     */
    void clear();

    void healthcheck();
}

