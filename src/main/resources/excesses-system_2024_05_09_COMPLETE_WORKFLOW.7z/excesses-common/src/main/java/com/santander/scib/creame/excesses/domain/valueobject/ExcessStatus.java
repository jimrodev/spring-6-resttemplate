package com.santander.scib.creame.excesses.domain.valueobject;

public enum ExcessStatus {

    PENDING(0), FILTERED(1), UNFILTERED(2) , ASSIGNED(3), RESOLVED(4), FAILED(5);

    private final Integer excessStatus;
    ExcessStatus(Integer excessStatus){
        this.excessStatus = excessStatus;
    }
    public Integer getExcessStatus(){
        return excessStatus;
    }
}
