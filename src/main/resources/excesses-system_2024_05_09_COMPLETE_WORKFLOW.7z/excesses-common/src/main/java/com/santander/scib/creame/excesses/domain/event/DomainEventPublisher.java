package com.santander.scib.creame.excesses.domain.event;

public interface DomainEventPublisher<T extends DomainEvent> {
    void publish(T domainEvent);
}
