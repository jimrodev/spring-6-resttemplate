package com.santander.scib.creame.excesses.domain.event;

import java.time.ZonedDateTime;

public interface DomainEvent<T> {
    String getId();
    T getEntity();
    ZonedDateTime getCreatedAt();
}
