package com.santander.scib.creame.excesses.application.outbox;

import java.util.function.BiConsumer;

public interface OutboxMessagePublisher<T> {
    void publish(T outboxMessage, BiConsumer<T, OutboxStatus> outboxCallback);
}
