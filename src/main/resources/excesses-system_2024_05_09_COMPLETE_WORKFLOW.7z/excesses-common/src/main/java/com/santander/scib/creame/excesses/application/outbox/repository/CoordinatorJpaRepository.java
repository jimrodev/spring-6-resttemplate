package com.santander.scib.creame.excesses.application.outbox.repository;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.application.outbox.entity.CoordinatorEntity;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface CoordinatorJpaRepository extends JpaRepository<CoordinatorEntity, UUID> {

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO CoordinatorEntity " +
            "(outbox_id, " +
            "saga_id, " +
            "created_at, " +
            "processed_at, " +
            "event_source, " +
            "event_target, " +
            "message_id, " +
            "payload, " +
            "context, " +
            "outbox_status, " +
            "saga_status, " +
            "version)" +
            " VALUES " +
            "(" +
            ":#{#ce.outboxId}," +
            ":#{#ce.sagaId}," +
            ":#{#ce.createdAt}," +
            ":#{#ce.processedAt}," +
            ":#{#ce.eventSource}," +
            ":#{#ce.eventTarget}," +
            ":#{#ce.messageId}," +
            ":#{#ce.payload}," +
            ":#{#ce.context}," +
            ":#{#ce.outboxStatus.name()}," +
            ":#{#ce.sagaStatus.name()}," +
            ":#{#ce.version}" +
            ")", nativeQuery = true)
    public abstract int insert(@Param("ce") CoordinatorEntity ce);

    @Query(value = "SELECT ce FROM CoordinatorEntity ce WHERE " +
            "ce.eventSource = :eventSource AND " +
            "ce.eventTarget = :eventTarget AND " +
            "ce.sagaId = :sagaId AND " +
            "ce.sagaStatus IN :sagaStatus")
    Optional<CoordinatorEntity> findBySagaIdAndSagaStatus(@Param("eventSource") String eventSource,
                                                          @Param("eventTarget") String eventTarget,
                                                          @Param("sagaId") UUID sagaId,
                                                          @Param("sagaStatus") List<SagaStatus> sagaStatus);
    @Modifying
    @Transactional
    @Query(value = "UPDATE CoordinatorEntity ce SET " +
            "ce.sagaId = :#{#ce.sagaId}, " +
            "ce.createdAt = :#{#ce.createdAt}, " +
            "ce.processedAt = :#{#ce.processedAt}, " +
            "ce.eventSource = :#{#ce.eventSource}, " +
            "ce.eventTarget = :#{#ce.eventTarget}, " +
            "ce.messageId = :#{#ce.messageId}, " +
            "ce.payload = :#{#ce.payload}, " +
            "ce.context = :#{#ce.context}, " +
            "ce.sagaStatus = :#{#ce.sagaStatus.name()}, " +
            "ce.outboxStatus = :#{#ce.outboxStatus.name()}, " +
            "ce.version = :#{#ce.version} " +
            "WHERE " +
            "ce.outboxId = :#{#ce.outboxId}" )
    public abstract int update(@Param("ce") CoordinatorEntity ce);

    @Modifying
    @Transactional
    @Query(value = "UPDATE CoordinatorEntity ce SET " +
            "ce.outboxStatus = :newOutboxStatus " +
            "WHERE " +
            "ce.eventSource = :eventSource AND " +
            "ce.eventTarget = :eventTarget AND " +
            "ce.outboxStatus IN :outboxStatus AND " +
            "ce.sagaStatus IN :sagaStatus AND " +
            "ce.processedAt < :processedAt ")
            //"DATEDIFF(MINUTE, ce.processedAt, SYSDATETIME()) > :retryInterval ")
    public abstract int updateByOutboxStatusAndProcessedAt(@Param("eventSource") String eventSource,
                                                           @Param("eventTarget") String eventTarget,
                                                           @Param("outboxStatus") List<OutboxStatus> outboxStatus,
                                                           @Param("sagaStatus") List<SagaStatus> sagaStatus,
                                                           @Param("processedAt") ZonedDateTime processedAt,
                                                           @Param("newOutboxStatus") OutboxStatus newOutboxStatus);

    @Modifying
    @Transactional
    @Query(value = "UPDATE CoordinatorEntity ce SET " +
            "ce.sagaStatus = :newSagaStatus " +
            "WHERE " +
            "ce.sagaId = :sagaId AND " +
            "ce.sagaStatus IN :sagaStatus")
    int updateBySagaIdAndSagaStatus(@Param("sagaId") UUID sagaId,
                                    @Param("sagaStatus") List<SagaStatus> sagaStatus,
                                    @Param("newSagaStatus") SagaStatus newSagaStatus);

    @Query(value = "SELECT ce FROM CoordinatorEntity ce WHERE " +
            "ce.eventSource = :eventSource AND " +
            "ce.eventTarget = :eventTarget AND " +
            "ce.outboxStatus IN :outboxStatus AND " +
            "ce.sagaStatus IN :sagaStatus ")
    Optional<List<CoordinatorEntity>> findByOutboxStatusAndSagaStatus(@Param("eventSource") String eventSource,
                                                                      @Param("eventTarget") String eventTarget,
                                                                      @Param("outboxStatus") List<OutboxStatus> outboxStatus,
                                                                      @Param("sagaStatus") List<SagaStatus> sagaStatus,
                                                                      Pageable pageable);
    @Query(value = "SELECT ce FROM CoordinatorEntity ce WHERE " +
            "ce.createdAt  >= :createdAt AND " +
            "ce.eventSource = :eventSource AND " +
            "ce.eventTarget = :eventTarget AND " +
            "ce.outboxStatus IN :outboxStatus AND " +
            "ce.sagaStatus IN :sagaStatus ")
    Optional<List<CoordinatorEntity>> findByCreatedAtAndOutboxStatusAndSagaStatus(@Param("eventSource") String eventSource,
                                                                                  @Param("eventTarget") String eventTarget,
                                                                                  @Param("createdAt") ZonedDateTime createdAt,
                                                                                  @Param("outboxStatus") List<OutboxStatus> outboxStatus,
                                                                                  @Param("sagaStatus") List<SagaStatus> sagaStatus,
                                                                                  Pageable pageable);
    @Modifying
    @Transactional
    @Query(value = "DELETE CoordinatorEntity ce WHERE " +
            "ce.eventSource = :eventSource AND " +
            "ce.eventTarget = :eventTarget AND " +
            "ce.outboxStatus IN :outboxStatus AND " +
            "ce.sagaStatus IN :sagaStatus")
    int deleteByOutboxStatusAndSagaStatus(@Param("eventSource") String eventSource,
                                          @Param("eventTarget") String eventTarget,
                                          @Param("outboxStatus") List<OutboxStatus> outboxStatus,
                                          @Param("sagaStatus") List<SagaStatus> sagaStatus);
}
