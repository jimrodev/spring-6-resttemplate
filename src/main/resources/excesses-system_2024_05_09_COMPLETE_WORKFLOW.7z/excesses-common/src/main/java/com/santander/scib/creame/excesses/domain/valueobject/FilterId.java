package com.santander.scib.creame.excesses.domain.valueobject;

import java.util.UUID;

public class FilterId extends BaseId<UUID>{

    public FilterId(UUID value) {
        super(value);
    }
}
