package com.santander.scib.creame.excesses.application.outbox.helper;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.SpoolQueue;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.repository.CoordinatorRepository;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.excesses.domain.event.DomainEvent;
import com.santander.scib.creame.excesses.domain.exception.DomainException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

@Slf4j
public abstract class CoordinatorHelper<T extends CoordinatorRepository> {

    private final SpoolQueue spoolQueue;
    private final String eventSource;
    private final String eventTarget;
    private final SpoolConfigData spoolConfigData;
    private final T coordinatorRepository;

    public CoordinatorHelper(String eventSource,
                             String eventTarget,
                             SpoolConfigData spoolConfigData,
                             T coordinatorRepository) {
        this.eventSource = eventSource;
        this.eventTarget = eventTarget;
        this.spoolConfigData = spoolConfigData;
        this.coordinatorRepository = coordinatorRepository;

        // Coordinator SpoolQueue
        this.spoolQueue = new SpoolQueue(this.spoolConfigData);
    }

    @Transactional(readOnly = true)
    public Optional<List<CoordinatorMessage>>
    getOutboxMessageByOutboxStatusAndSagaStatus(List<OutboxStatus> outboxStatus,
                                                SagaStatus... sagaStatus) {
        return OutboxCommonHelper.filterSpoolQueue(
                this.spoolQueue,
                this.coordinatorRepository
                    .findByOutboxStatusAndSagaStatus(
                        this.spoolConfigData.getMaxBatchSize(),
                        outboxStatus,
                        sagaStatus)
                );
    }

    @Transactional(readOnly = true)
    public Optional<List<CoordinatorMessage>>
    getOutboxMessageByCreatedAtAndOutboxStatusAndSagaStatus(ZonedDateTime createdAt,
                                                            List<OutboxStatus> outboxStatus,
                                                            SagaStatus... sagaStatus) {
        return OutboxCommonHelper.filterSpoolQueue(
                this.spoolQueue,
                this.coordinatorRepository
                .findByCreatedAtAndOutboxStatusAndSagaStatus(
                        this.spoolConfigData.getMaxBatchSize(),
                        createdAt,
                        outboxStatus,
                        sagaStatus)
                );
    }

    @Transactional(readOnly = true)
    public Optional<CoordinatorMessage>
    getOutboxMessageBySagaIdAndSagaStatus(UUID sagaId,
                                          SagaStatus... sagaStatus) {
        return coordinatorRepository
                .findBySagaIdAndSagaStatus(
                    sagaId,
                    sagaStatus);
    }

    private void save(CoordinatorMessage coordinatorMessage) {
        CoordinatorMessage response = coordinatorRepository.save(coordinatorMessage);
        if (response == null) {
            log.error("Could not save CoordinatorMessage with message id: {} and outbox id: {}",
                    coordinatorMessage.getMessageId(),
                    coordinatorMessage.getOutboxId());
            throw new DomainException("Could not save CoordinatorMessage with message id: " +
                    coordinatorMessage.getMessageId() +
                    " and outbox id: " +
                    coordinatorMessage.getOutboxId());
        }
        log.info("CoordinatorMessage saved with message id: {} and outbox id: {}",
                coordinatorMessage.getMessageId(),
                coordinatorMessage.getOutboxId());
    }

    @Transactional
    public <U, V> void saveCoordinatorMessage(UUID sagaId,
                                              SagaStatus sagaStatus,
                                              UUID outboxId,
                                              OutboxStatus outboxStatus,
                                              DomainEvent<U> domainEvent,
                                              Function<U, V> mapper,
                                              ContextMessage context)
    {

        save(CoordinatorMessage.builder()
                .outboxId(outboxId)
                .sagaId(sagaId)
                .createdAt(domainEvent.getCreatedAt())
                .messageId(domainEvent.getId())
                .payload(OutboxCommonHelper.serializePayload(outboxId, mapper.apply(domainEvent.getEntity())))
                .context(OutboxCommonHelper.serializeContext(outboxId, context))
                .eventSource(this.eventSource)
                .eventTarget(this.eventTarget)
                .sagaStatus(sagaStatus)
                .outboxStatus(outboxStatus)
                .isNew(true)
                .build());
    }

    @Transactional
    public int deleteOutboxMessageByOutboxStatusAndSagaStatus(List<OutboxStatus> outboxStatus,
                                                              SagaStatus... sagaStatus) {
        return coordinatorRepository
                .deleteByOutboxStatusAndSagaStatus(outboxStatus,
                                                   sagaStatus);
    }

    @Transactional
    public void updateCoordinatorMessage(CoordinatorMessage coordinatorMessage) {
        coordinatorMessage.setNew(false);
        save(coordinatorMessage);

        log.info("CoordinatorMessage with outbox id: {} is updated ",
                coordinatorMessage.getOutboxId());
    }

    @Transactional
    public void updateOutboxStatus(CoordinatorMessage coordinatorMessage, OutboxStatus outboxStatus) {

        coordinatorMessage.setOutboxStatus(outboxStatus);
        coordinatorMessage.setProcessedAt(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
        coordinatorMessage.setNew(false);
        save(coordinatorMessage);

        // Remove from spool queue
        if(this.spoolConfigData.getSpoolQueue()
                               .getEntryClean()) {
            spoolQueue.getSpoolQueue().remove(coordinatorMessage.getOutboxId());

        } else {
            // Update queue last process at
            if(spoolQueue.getSpoolQueue().containsKey(coordinatorMessage.getOutboxId())) {

                // Update spool queue info
                SpoolQueue.QueueInfo queueInfo = spoolQueue.getSpoolQueue().get(coordinatorMessage.getOutboxId());
                queueInfo.setLastProcessedAt(coordinatorMessage.getProcessedAt());
            }
        }

        log.info("CoordinatorMessage with outbox id: {} is updated with outbox status: {}",
                coordinatorMessage.getOutboxId(),
                outboxStatus.name());
    }

    @Transactional
    public int updateOutboxMessageBySagaIdAndSagaStatus(UUID sagaId,
                                                        List<SagaStatus> sagaStatus,
                                                        SagaStatus newSagaStatus) {
        return coordinatorRepository
                .updateBySagaIdAndSagaStatus(sagaId,
                                             sagaStatus,
                                             newSagaStatus);
    }

    @Transactional
    public int updateOutboxMessageByOutboxStatusAndProcessedAt(List<OutboxStatus> outboxStatus,
                                                               Integer retryInterval,
                                                               OutboxStatus newOutboxStatus) {

        if(spoolConfigData.getTransportOptions().getEnableFaultTolerance()) {
            return coordinatorRepository
                    .updateByOutboxStatusAndSagaStatusAndProcessedAt(
                            outboxStatus,
                            Arrays.asList(SagaStatus.STARTED, SagaStatus.CONTINUATION, SagaStatus.COMPENSATING),
                            retryInterval,
                            newOutboxStatus);
        }else
            return 0;
    }
}
