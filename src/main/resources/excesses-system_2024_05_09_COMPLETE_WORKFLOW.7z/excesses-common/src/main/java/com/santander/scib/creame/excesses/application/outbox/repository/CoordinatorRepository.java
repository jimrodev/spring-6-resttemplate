package com.santander.scib.creame.excesses.application.outbox.repository;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CoordinatorRepository {
    int insert(CoordinatorMessage coordinatorMessage);

    int update(CoordinatorMessage coordinatorMessage);

    CoordinatorMessage save(CoordinatorMessage coordinatorMessage);

    Optional<CoordinatorMessage> findBySagaIdAndSagaStatus(UUID sagaId,
                                                           SagaStatus... sagaStatus);

    int updateBySagaIdAndSagaStatus(UUID sagaId,
                                     List<SagaStatus> sagaStatus,
                                     SagaStatus newSagaStatus);

    int updateByOutboxStatusAndSagaStatusAndProcessedAt(List<OutboxStatus> outboxStatus,
                                                        List<SagaStatus> sagasStatus,
                                                        Integer retryInterval,
                                                        OutboxStatus newOutboxStatus);

    Optional<List<CoordinatorMessage>> findByOutboxStatusAndSagaStatus(Integer maxBatchSize,
                                                                       List<OutboxStatus> outboxStatus,
                                                                       SagaStatus... sagaStatus);

    Optional<List<CoordinatorMessage>> findByCreatedAtAndOutboxStatusAndSagaStatus(Integer maxBatchSize,
                                                                                   ZonedDateTime createdAt,
                                                                                   List<OutboxStatus> outboxStatus,
                                                                                   SagaStatus... sagaStatus);
    int deleteByOutboxStatusAndSagaStatus(List<OutboxStatus> outboxStatus,
                                          SagaStatus... sagaStatus);

    void flush();
}
