package com.santander.scib.creame.excesses.application.outbox.helper;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.OutboxMessage;
import com.santander.scib.creame.excesses.application.outbox.repository.OutboxRepository;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.domain.event.DomainEvent;
import com.santander.scib.creame.excesses.domain.exception.DomainException;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

@Slf4j
public abstract class OutboxHelper<T extends OutboxRepository> {

    private final String eventSource;
    private final String eventTarget;
    private final SpoolConfigData spoolConfigData;
    private final T outboxRepository;

    public OutboxHelper(String eventSource,
                        String eventTarget,
                        SpoolConfigData spoolConfigData,
                        T outboxRepository) {
        this.eventSource = eventSource;
        this.eventTarget = eventTarget;
        this.spoolConfigData = spoolConfigData;
        this.outboxRepository = outboxRepository;
    }

    private void save(OutboxMessage outboxMessage) {
        OutboxMessage response = outboxRepository.save(outboxMessage);

        if (response == null) {
            log.error("Could not save OutboxMessage with message id: {} and outbox id: {}",
                    outboxMessage.getMessageId(),
                    outboxMessage.getOutboxId());
            throw new DomainException("Could not save OutboxMessage with message id: " +
                    outboxMessage.getMessageId() +
                    " and outbox id: " +
                    outboxMessage.getOutboxId());
        }
        log.info("OutboxMessage saved with message id: {} and outbox id: {}",
                outboxMessage.getMessageId(),
                outboxMessage.getOutboxId());
    }

    @Transactional
    public <U, V> void saveOutBoxMessage(UUID outboxId,
                                         OutboxStatus outboxStatus,
                                         DomainEvent<U> domainEvent,
                                         Function<U, V> mapper,
                                         ContextMessage context)
    {
        save(OutboxMessage.builder()
                .outboxId(outboxId)
                .createdAt(domainEvent.getCreatedAt())
                .messageId(domainEvent.getId())
                .payload(OutboxCommonHelper.serializePayload(outboxId, mapper.apply(domainEvent.getEntity())))
                .context(OutboxCommonHelper.serializeContext(outboxId, context))
                .eventSource(this.eventSource)
                .eventTarget(this.eventTarget)
                .outboxStatus(outboxStatus)
                .isNew(true)
                .build());
    }

    @Transactional(readOnly = true)
    public Optional<List<OutboxMessage>> getOutboxMessageByOutboxStatus(OutboxStatus outboxStatus) {
        return outboxRepository
                .findByOutboxStatus(
                        this.spoolConfigData.getMaxBatchSize(),
                        outboxStatus);
    }

    @Transactional(readOnly = true)
    public Optional<List<OutboxMessage>>
    getOutboxMessageByCreatedAtAndOutboxStatus(ZonedDateTime createdAt,
                                               OutboxStatus outboxStatus) {
        return outboxRepository
                .findByCreatedAtAndOutboxStatus(
                        this.spoolConfigData.getMaxBatchSize(),
                        createdAt,
                        outboxStatus);
    }

    @Transactional
    public int deleteOutboxMessageByOutboxStatus(OutboxStatus outboxStatus) {
        return outboxRepository
                    .deleteByOutboxStatus(outboxStatus);
    }

    @Transactional
    public void updateOutboxMessage(OutboxMessage outboxMessage) {
        outboxMessage.setNew(false);
        save(outboxMessage);

        log.info("OutboxMessage with outbox id: {} is updated",
                outboxMessage.getOutboxId());
    }

    @Transactional
    public void updateOutboxStatus(OutboxMessage outboxMessage, OutboxStatus outboxStatus) {
        outboxMessage.setOutboxStatus(outboxStatus);
        outboxMessage.setProcessedAt(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)));
        int rowAffected = outboxRepository.update(outboxMessage);

        if (rowAffected == 1) {
            log.info("OutboxMessage with outbox id: {} is updated with outbox status: {}",
                    outboxMessage.getOutboxId(),
                    outboxStatus.name());
        }
    }
}
