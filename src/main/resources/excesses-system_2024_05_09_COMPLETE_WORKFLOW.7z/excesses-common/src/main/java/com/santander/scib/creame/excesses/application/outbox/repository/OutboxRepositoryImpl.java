package com.santander.scib.creame.excesses.application.outbox.repository;

import com.santander.scib.creame.excesses.application.outbox.dto.OutboxMessage;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.mapper.OutboxDataAccessMapper;
import org.springframework.data.domain.PageRequest;

import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public abstract class OutboxRepositoryImpl implements OutboxRepository {

    private final String eventSource;
    private final String eventTarget;
    private final OutboxJpaRepository outboxJpaRepository;
    private final OutboxDataAccessMapper outboxDataAccessMapper;

    public OutboxRepositoryImpl(String eventSource,
                                String eventTarget,
                                OutboxJpaRepository outboxJpaRepository,
                                OutboxDataAccessMapper outboxDataAccessMapper) {
        this.eventSource = eventSource;
        this.eventTarget = eventTarget;
        this.outboxJpaRepository = outboxJpaRepository;
        this.outboxDataAccessMapper = outboxDataAccessMapper;
    }

    @Override
    public int insert(OutboxMessage outboxMessage) {

        return outboxJpaRepository
                .insert(outboxDataAccessMapper.outboxMessageToOutboxEntity(outboxMessage));
    }

    @Override
    public int update(OutboxMessage outboxMessage) {

        return outboxJpaRepository
                .update(outboxDataAccessMapper.outboxMessageToOutboxEntity(outboxMessage));
    }

    @Override
    public OutboxMessage save(OutboxMessage outboxMessage) {
        return outboxDataAccessMapper
                .outboxEntityToOutboxMessage(outboxJpaRepository
                        .save(outboxDataAccessMapper
                                .outboxMessageToOutboxEntity(outboxMessage)));
    }

    @Override
    public Optional<List<OutboxMessage>> findByOutboxStatus(Integer maxBatchSize,
                                                            OutboxStatus outboxStatus) {
        return Optional.of(outboxJpaRepository
                .findByOutboxStatus(
                        this.eventSource,
                        this.eventTarget,
                        outboxStatus,
                        PageRequest.of(0,maxBatchSize))
                .stream()
                .flatMap(Collection::stream)
                .map(outboxDataAccessMapper::outboxEntityToOutboxMessage)
                .collect(Collectors.toList()));
    }

    @Override
    public Optional<List<OutboxMessage>> findByCreatedAtAndOutboxStatus(Integer maxBatchSize,
                                                                        ZonedDateTime createdAt,
                                                                        OutboxStatus outboxStatus) {
        return Optional.of(outboxJpaRepository
                .findByCreatedAtAndOutboxStatus(
                        this.eventSource,
                        this.eventTarget,
                        createdAt,
                        outboxStatus,
                        PageRequest.of(0,maxBatchSize))
                .stream()
                .flatMap(Collection::stream)
                .map(outboxDataAccessMapper::outboxEntityToOutboxMessage)
                .collect(Collectors.toList()));
    }

    @Override
    public int deleteByOutboxStatus(OutboxStatus outboxStatus) {
        return outboxJpaRepository
                    .deleteByOutboxStatus(
                        this.eventSource,
                        this.eventTarget,
                        outboxStatus);
    }

    @Override
    public void flush() {
        outboxJpaRepository.flush();
    }
}
