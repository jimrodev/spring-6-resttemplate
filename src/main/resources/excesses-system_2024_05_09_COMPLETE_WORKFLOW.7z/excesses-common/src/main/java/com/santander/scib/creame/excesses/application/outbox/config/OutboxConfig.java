package com.santander.scib.creame.excesses.application.outbox.config;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.resource.jdbc.spi.StatementInspector;
import org.springframework.boot.autoconfigure.orm.jpa.HibernatePropertiesCustomizer;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "app.outbox")
@Getter
@Setter
public class OutboxConfig {

    private Map<String, String> tables;
    private Map<String, SchedulerConfigData> schedulers;
    private Map<String, SpoolConfigData> spools;

    @Bean
    public Map<String, String> OutboxTables(){
        return new HashMap<>(tables);
    }
    @Bean
    public Map<String, SchedulerConfigData> Schedulers() {return new HashMap<>(schedulers);
    }
    @Bean
    public Map<String, SpoolConfigData> Spools() {return new HashMap<>(spools);}
    //@Bean
    public HibernatePropertiesCustomizer hibernateCustomizer(StatementInspector statementInspector) {
        return (properties) -> properties.put(AvailableSettings.STATEMENT_INSPECTOR, statementInspector);
    }
}
