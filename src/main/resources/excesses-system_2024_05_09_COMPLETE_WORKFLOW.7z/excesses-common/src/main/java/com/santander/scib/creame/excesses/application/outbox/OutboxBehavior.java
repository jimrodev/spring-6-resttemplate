package com.santander.scib.creame.excesses.application.outbox;

import java.util.UUID;

/**
 * Interface for Outbox Messages.
 * This interface provides common behavior for outbox and coordinator message
 */
public interface OutboxBehavior {

    String getMessageId();

    UUID getOutboxId();

    UUID getSagaId();

    String getPayload();

    String getContext();
}
