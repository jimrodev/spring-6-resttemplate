package com.santander.scib.creame.excesses.application.outbox.exception;

public class OutboxNotFoundException extends RuntimeException {

    public OutboxNotFoundException(String message) {
        super(message);
    }
}
