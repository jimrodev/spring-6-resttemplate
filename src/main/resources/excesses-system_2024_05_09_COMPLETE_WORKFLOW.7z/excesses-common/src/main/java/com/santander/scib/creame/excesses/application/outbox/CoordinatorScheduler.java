package com.santander.scib.creame.excesses.application.outbox;

import com.santander.scib.creame.excesses.application.outbox.config.SchedulerConfigData;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.CoordinatorHelper;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZonedDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.santander.scib.creame.excesses.application.outbox.OutboxStatus.RETRY;
import static com.santander.scib.creame.excesses.application.outbox.OutboxStatus.STARTED;

/**
 * Implementation of the SpoolScheduler interface for Coordinator messages.
 *
 * @param <T> the type of the Helper. This type must extend CoordinatorHelper interface
 * CoordinatorHelper contains the common behavior when dealing with CoordinatorRepository output ports
 *
 * @param <U> the type of the MessagePublisher. This type must extend OutboxMessagePublisher interface
 * OutboxMessagePublisher contains the common behavior when dealing with OutboxMessagePublisher output ports
 */
@Slf4j
@Configuration
@EnableScheduling
public abstract class CoordinatorScheduler<T extends CoordinatorHelper<?>, U extends OutboxMessagePublisher<CoordinatorMessage>> implements SpoolScheduler{

    private final SpoolConfigData spoolConfigData;
    private final T coordinatorHelper;
    private final U outBoxMessagePublisher;
    private ZonedDateTime currentCreateAt;

    /**
     * Constructs a CoordinatorScheduler with the given CoordinatorHelper and OutboxMessagePublisher.
     *
     * @param coordinatorHelper,      CoordinatorHelper implementation that contains the CoordinatorRepository output port implementations to interact with the database
     * @param outBoxMessagePublisher, OutboxMessagePublisher output port implementation to interact with the event bus
     */
    public CoordinatorScheduler(SpoolConfigData spoolConfigData,
                                T coordinatorHelper,
                                U outBoxMessagePublisher) {
        this.spoolConfigData = spoolConfigData;
        this.coordinatorHelper = coordinatorHelper;
        this.outBoxMessagePublisher = outBoxMessagePublisher;
        this.currentCreateAt = null;
    }

    /**
     * Processes a batch of messages from the Spool table.
     */
    public void process() {
        Optional<List<CoordinatorMessage>> outboxMessages = Optional.empty();

        // PROCESS SPOOL TABLE
        // FIRST SLIDE (SpoolBatchSize)
        if (currentCreateAt == null){
            outboxMessages = coordinatorHelper.getOutboxMessageByOutboxStatusAndSagaStatus(
                            Arrays.asList(STARTED, RETRY),
                            SagaStatus.STARTED,
                            SagaStatus.CONTINUATION,
                            SagaStatus.COMPENSATING);   // REVISAR LOS ESTADOS
        }else {
            // Go through the table until the end
            // NEXT SLIDE (SpoolBatchSize)
            outboxMessages = coordinatorHelper.getOutboxMessageByCreatedAtAndOutboxStatusAndSagaStatus(
                            this.currentCreateAt,
                            Arrays.asList(STARTED, RETRY),
                            SagaStatus.STARTED,
                            SagaStatus.CONTINUATION,
                            SagaStatus.COMPENSATING);   // REVISAR LOS ESTADOS
        }
        log.info("Coordinator scheduler found {} OutboxMessages ", outboxMessages.get().isEmpty()?0:outboxMessages.get().size());

        if (outboxMessages.isPresent() && !outboxMessages.get().isEmpty()) {
            List<CoordinatorMessage> outboxMessagesList = outboxMessages.get();
            /*log.info("Received {} OutboxMessages with ids: {}, sending to message bus!",
                    outboxMessagesList.size(),
                    outboxMessagesList.stream().map(outboxMessage ->
                            outboxMessage.getOutboxId().toString()).collect(Collectors.joining(",")));*/
            outboxMessagesList
                    .parallelStream()
                    .forEach(outboxMessage -> {
                            outBoxMessagePublisher.publish(outboxMessage,
                                                           coordinatorHelper::updateOutboxStatus);
                    });

            this.currentCreateAt = outboxMessagesList.get(outboxMessagesList.size()-1).getCreatedAt();
        } else {
            // RESTART THE PROCESS
            this.currentCreateAt = null;
        }
    }

    /**
     * Clear the Spool table.
     */
    public void clear() {
        Optional<List<CoordinatorMessage>> outboxMessages =
                coordinatorHelper.getOutboxMessageByOutboxStatusAndSagaStatus(
                        List.of(OutboxStatus.COMPLETED),
                        SagaStatus.COMPLETED,
                        SagaStatus.COMPENSATED);
                        // ** SagaStatus.FAILED
                        // QUE HACEMOS CON LAS FAILED
                        // PONER UN RETRY COUNT Y RETRY INTERVAL
                        // ESTE CASO HAY QUE ANALIZARLO

        // EN PRODUCCIÓN PODEMOS EJECUTARLO SIN LA CONSULTA PREVIA
        if (outboxMessages.isPresent() && (!outboxMessages.get().isEmpty())) {
            List<CoordinatorMessage> outboxMessagesList = outboxMessages.get();
            log.info("Received {} OutboxMessages for clean-up. ids: {}",
                    outboxMessagesList.size(),
                    outboxMessagesList.stream().map(outboxMessage ->
                            outboxMessage.getOutboxId().toString()).collect(Collectors.joining(",")));

            int rowsAffected = coordinatorHelper.deleteOutboxMessageByOutboxStatusAndSagaStatus(
                                                                                    List.of(OutboxStatus.COMPLETED),
                                                                                    SagaStatus.COMPLETED,
                                                                                    SagaStatus.COMPENSATED);
            log.info("{} OrderPaymentOutboxMessage deleted!", rowsAffected);
        }
    }

    public void healthcheck(){
        // RETRY FAILED MESSAGES
        // BY Rertry Interval
        if(spoolConfigData.getTransportOptions().getEnableFaultTolerance())
        {
            coordinatorHelper
                    .updateOutboxMessageByOutboxStatusAndProcessedAt(List.of(OutboxStatus.FAILED),
                                                                    spoolConfigData.getTransportOptions().getRetryInterval(),
                                                                    OutboxStatus.RETRY);
        }
    }
}
