package com.santander.scib.creame.excesses.application.outbox;

/**
 * Class with the Excesses's Stakeholders
 * EXCESS, FILTER, WORKFLOW, ALERT, NOTIFICATION
 */
public final class Stakeholders {

    public static final String EXCESS = "EXCESS";
    public static final String FILTER = "FILTER";
    public static final String WORKFLOW = "WORKFLOW";
    public static final String ALERT = "ALERT";
    public static final String NOTIFICATION =  "NOTIFICATION";

    private Stakeholders(){}
}
