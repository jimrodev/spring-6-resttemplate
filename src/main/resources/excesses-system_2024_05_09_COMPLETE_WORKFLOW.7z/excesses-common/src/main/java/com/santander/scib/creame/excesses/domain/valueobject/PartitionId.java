package com.santander.scib.creame.excesses.domain.valueobject;


public class PartitionId extends BaseId<String>{

    public PartitionId(String value) {
        super(value);
    }
}
