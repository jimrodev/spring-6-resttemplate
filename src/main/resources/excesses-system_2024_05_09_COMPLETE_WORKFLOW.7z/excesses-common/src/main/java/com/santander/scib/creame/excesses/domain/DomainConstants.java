package com.santander.scib.creame.excesses.domain;

public class DomainConstants {

    private DomainConstants() {
    }

    public static final String UTC = "UTC";
}
