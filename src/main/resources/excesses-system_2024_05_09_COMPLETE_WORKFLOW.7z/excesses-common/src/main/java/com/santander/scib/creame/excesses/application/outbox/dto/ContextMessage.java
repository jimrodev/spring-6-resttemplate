package com.santander.scib.creame.excesses.application.outbox.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Data Transfer Object with message's context properties.These properties are used for subscription purposes.
 * The context properties are ship along the message over the event bus.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class ContextMessage {
    /**
     * Message Engine properties, are the core properties for the Message Engine (SAGA, Subscriptions)
     * Prefix: EME
     * EME.messageId: Is the unique identifier of the message in the system (Excess primary Key)
     * EME.interchangeId: Defines the unique ID that is used to group the messages that resulted from the same interchange among async services.
     * EME.messageType: Specifies the type of the message.
     * EME.eventSource: The source of the event.
     * EME.InboundTransportType: Specifies the type of adapter that received this message and submitted it into the system. s3://, https://, file://, kafka://
     * EME.InboundTransportLocation: Specifies the location (URI) on which the message was received by the handler.
     * EME.OutboundTransportType: Specifies the type of adapter used to send the message. The available adapter types are s3://, https://, file://, kafka://
     * EME.OutboundTransportLocation: Specifies the destination location URI where the message is sent. The URI may contain the adapter prefix, such as http://.
     *                                The adapter prefix is used by the Messaging Engine to determine the type of adapter to use when sending the message.
     * EME.ReceivePortID: Identifies the receive port on which the message was received.
     * EME.SendPortID: Specifies the ID of the send port.
     * EME.FailureCode: Error code associated to the current message
     * EME.FailureMessages: Array with the error description
     * EME.BatchId: Identifies the current Batch of messages
     * EME.BatchTotalNumber: Specifies the messages total number in the current batch.
     * EME.BatchSequenceNumber: Specifies the position of the current message in the batch.
     *
     * S3 Properties: The properties related with the s3 transport protocol
     * Prefix: S3
     * S3.BucketName: The name of the S3 bucket
     * S3.s3keyName: The key of the file in the S3 bucket
     */
    @JsonProperty
    private String messageId;
    @JsonProperty
    private String messageType;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private UUID interchangeId;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String eventSource;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String inboundTransportType;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String inboundTransportLocation;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String outboundTransportType;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String outboundTransportLocation;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String receivePortID;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String sendPortID;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String failureCode;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String failureMessages;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String batchId;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String batchTotalNumber;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String batchSequenceNumber;
    /**
     * s3:// properties, are the properties related with the s3 transport protocol
     */
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String s3BucketName;
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String s3keyName;

    /**
     * http://, https:// properties, are the properties related with the http transport protocol
     */

}
