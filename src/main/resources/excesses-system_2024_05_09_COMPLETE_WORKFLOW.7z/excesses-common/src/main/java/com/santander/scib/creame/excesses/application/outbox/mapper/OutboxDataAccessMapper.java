package com.santander.scib.creame.excesses.application.outbox.mapper;

import com.santander.scib.creame.excesses.application.outbox.dto.OutboxMessage;
import com.santander.scib.creame.excesses.application.outbox.entity.OutboxEntity;
import org.springframework.stereotype.Component;

@Component
public class OutboxDataAccessMapper {

    public OutboxEntity outboxMessageToOutboxEntity(OutboxMessage outboxMessage) {
        return OutboxEntity.builder()
                .outboxId(outboxMessage.getOutboxId())
                .createdAt(outboxMessage.getCreatedAt())
                .eventSource(outboxMessage.getEventSource())
                .eventTarget(outboxMessage.getEventTarget())
                .messageId(outboxMessage.getMessageId())
                .payload(outboxMessage.getPayload())
                .context(outboxMessage.getContext())
                .outboxStatus(outboxMessage.getOutboxStatus())
                .version(outboxMessage.getVersion())
                .isNew(outboxMessage.isNew())
                .build();
    }

    public OutboxMessage outboxEntityToOutboxMessage(OutboxEntity outboxEntity) {
        return OutboxMessage.builder()
                .outboxId(outboxEntity.getOutboxId())
                .createdAt(outboxEntity.getCreatedAt())
                .eventSource(outboxEntity.getEventSource())
                .eventTarget(outboxEntity.getEventTarget())
                .messageId(outboxEntity.getMessageId())
                .payload(outboxEntity.getPayload())
                .context(outboxEntity.getContext())
                .outboxStatus(outboxEntity.getOutboxStatus())
                .version(outboxEntity.getVersion())
                .isNew(false)
                .build();
    }
}
