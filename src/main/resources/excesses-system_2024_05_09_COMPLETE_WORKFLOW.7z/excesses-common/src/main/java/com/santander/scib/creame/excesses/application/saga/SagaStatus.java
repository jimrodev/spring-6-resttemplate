package com.santander.scib.creame.excesses.application.saga;

public enum SagaStatus {

    STARTED, COMPLETED, RETRY, FAILED, CONTINUATION, COMPENSATING, COMPENSATED
}
