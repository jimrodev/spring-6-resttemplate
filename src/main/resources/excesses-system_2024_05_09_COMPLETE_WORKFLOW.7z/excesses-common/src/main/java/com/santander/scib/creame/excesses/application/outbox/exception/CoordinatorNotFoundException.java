package com.santander.scib.creame.excesses.application.outbox.exception;

public class CoordinatorNotFoundException extends RuntimeException {

    public CoordinatorNotFoundException(String message) {
        super(message);
    }
}
