package com.santander.scib.creame.excesses.application.outbox.mapper;

import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.entity.CoordinatorEntity;
import org.springframework.stereotype.Component;

@Component
public class CoordinatorDataAccessMapper {

    public CoordinatorEntity coordinatorMessageToCoordinatorEntity(CoordinatorMessage coordinatorMessage) {
        return CoordinatorEntity.builder()
                .outboxId(coordinatorMessage.getOutboxId())
                .sagaId(coordinatorMessage.getSagaId())
                .createdAt(coordinatorMessage.getCreatedAt())
                .processedAt(coordinatorMessage.getProcessedAt())
                .eventSource(coordinatorMessage.getEventSource())
                .eventTarget(coordinatorMessage.getEventTarget())
                .messageId(coordinatorMessage.getMessageId())
                .payload(coordinatorMessage.getPayload())
                .context(coordinatorMessage.getContext())
                .sagaStatus(coordinatorMessage.getSagaStatus())
                .outboxStatus(coordinatorMessage.getOutboxStatus())
                .version(coordinatorMessage.getVersion())
                .isNew(coordinatorMessage.isNew())
                .build();
    }

    public CoordinatorMessage coordinatorEntityCoordinatorMessage(CoordinatorEntity coordinatorEntity) {
        return CoordinatorMessage.builder()
                .outboxId(coordinatorEntity.getOutboxId())
                .sagaId(coordinatorEntity.getSagaId())
                .createdAt(coordinatorEntity.getCreatedAt())
                .processedAt(coordinatorEntity.getProcessedAt())
                .eventSource(coordinatorEntity.getEventSource())
                .eventTarget(coordinatorEntity.getEventTarget())
                .messageId(coordinatorEntity.getMessageId())
                .payload(coordinatorEntity.getPayload())
                .context(coordinatorEntity.getContext())
                .sagaStatus(coordinatorEntity.getSagaStatus())
                .outboxStatus(coordinatorEntity.getOutboxStatus())
                .version(coordinatorEntity.getVersion())
                .isNew(false)
                .build();
    }
}
