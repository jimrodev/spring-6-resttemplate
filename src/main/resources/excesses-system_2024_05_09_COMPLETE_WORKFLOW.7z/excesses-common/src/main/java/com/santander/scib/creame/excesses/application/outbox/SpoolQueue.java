package com.santander.scib.creame.excesses.application.outbox;

import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import lombok.Getter;

import java.time.ZonedDateTime;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Getter
public class SpoolQueue {

    private final SpoolConfigData spoolConfigData;

    // Queue statistics for Throttling algorithm
    @Getter
    private static class QueueStatistics{
        private Integer retryCounter;
        private Integer failedCounter;

        public QueueStatistics() {
            this.retryCounter = 0;
            this.failedCounter = 0;
        }

        public void setRetryCounter(Integer retryCounter) {
            this.retryCounter = retryCounter;
        }

        public void setFailedCounter(Integer failedCounter) {
            this.failedCounter = failedCounter;
        }

        public void incrementRetryCounter(){this.retryCounter+=1;}
        public void incrementFailedCounter(){this.failedCounter+=1;}
    };

    @Getter
    public static final class QueueInfo{
        private final UUID outboxId;
        private final ZonedDateTime createdAt;
        private ZonedDateTime lastProcessedAt;
        private Integer schedulerPassCount;
        private OutboxStatus outboxStatus;
        private Integer retryCount;

        public QueueInfo(UUID outboxId, 
                         ZonedDateTime createdAt,
                         OutboxStatus outboxStatus) {
            this.outboxId = outboxId;
            this.createdAt = createdAt;
            this.lastProcessedAt = this.createdAt;
            this.schedulerPassCount = 1;
            this.outboxStatus = outboxStatus;
            this.retryCount = 0;
        }

        public void setLastProcessedAt(ZonedDateTime processedAt)
        {
            this.lastProcessedAt = processedAt;
        }
        public void setOutboxStatus(OutboxStatus outboxStatus) {this.outboxStatus = outboxStatus;}

        public void incrementPassCount(){this.schedulerPassCount+=1;}
        public void incrementRetryCount(){this.retryCount+=1;}
   }

    private final Map<UUID, QueueInfo> spoolQueue;
    private final QueueStatistics queueStatistics;

    public SpoolQueue(SpoolConfigData spoolConfigData) {
        this.spoolConfigData = spoolConfigData;

        // Create a spool queue with initial Queue Depth
        this.spoolQueue = new ConcurrentHashMap<UUID, QueueInfo>(spoolConfigData.getSpoolQueue().getQueueDepth());
        this.queueStatistics = new QueueStatistics();
    }
}
