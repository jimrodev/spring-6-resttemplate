package com.santander.scib.creame.filter.service.domain.application.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import org.springframework.stereotype.Component;

@Component
public class FilterDataMapper {

    public Filter filterRequestToFilter(FilterRequest filterRequest){
        return Filter.builder()
                .excessId(new ExcessId(filterRequest.getExcessId()))
                .processTimestamp(filterRequest.getProcessTimestamp())
                .build();
    }

    public FilterResponse FilterToFilterResponse(Filter filter) {
        return FilterResponse.builder()
                .filterId(filter.getId().getValue().toString())
                .excessId(filter.getExcessId().getValue())
                .processTimestamp(filter.getProcessTimestamp())
                .filterStatus(filter.getFilterStatus())
                .filtersMatching(filter.getFiltersMatching())
                .build();
    }
}
