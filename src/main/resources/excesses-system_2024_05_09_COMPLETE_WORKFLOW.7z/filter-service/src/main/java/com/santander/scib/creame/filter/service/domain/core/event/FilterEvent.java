package com.santander.scib.creame.filter.service.domain.core.event;

import com.santander.scib.creame.excesses.domain.event.DomainEvent;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;

import java.time.ZonedDateTime;

public abstract class FilterEvent implements DomainEvent<Filter> {
    private final Filter filter;
    private final ZonedDateTime createdAt;

    public FilterEvent(Filter filter, ZonedDateTime createdAt) {
        this.filter = filter;
        this.createdAt = createdAt;
    }

    @Override
    public Filter getEntity() {
        return this.filter;
    }

    @Override
    public ZonedDateTime getCreatedAt() {
        return this.createdAt;
    }

    @Override
    public String getId(){
        return this.filter.getId().getValue().toString();
    }
}

