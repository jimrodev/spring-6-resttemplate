package com.santander.scib.creame.filter.service.domain.core.event;

import com.santander.scib.creame.filter.service.domain.core.entity.Filter;

import java.time.ZonedDateTime;

public class FilteredEvent extends FilterEvent {

    public FilteredEvent(Filter filter,
                         ZonedDateTime createdAt) {
        super(filter, createdAt);
    }
}
