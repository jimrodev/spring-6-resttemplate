package com.santander.scib.creame.filter.service.domain.core.event;

import com.santander.scib.creame.filter.service.domain.core.entity.Filter;

import java.time.ZonedDateTime;

public class UnfilteredEvent extends FilterEvent{
    public UnfilteredEvent(Filter filter,
                           ZonedDateTime createdAt) {
        super(filter, createdAt);
    }
}
