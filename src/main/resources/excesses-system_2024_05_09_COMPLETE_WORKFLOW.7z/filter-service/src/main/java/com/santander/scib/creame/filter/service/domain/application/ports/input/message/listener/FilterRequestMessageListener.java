package com.santander.scib.creame.filter.service.domain.application.ports.input.message.listener;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import jakarta.validation.Valid;

public interface FilterRequestMessageListener {
    void apply (@Valid FilterRequest filterRequest, @Valid ContextMessage context);
}
