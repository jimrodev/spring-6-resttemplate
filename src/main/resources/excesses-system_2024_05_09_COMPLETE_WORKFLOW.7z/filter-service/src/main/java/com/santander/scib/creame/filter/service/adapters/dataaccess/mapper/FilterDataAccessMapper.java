package com.santander.scib.creame.filter.service.adapters.dataaccess.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.domain.valueobject.FilterId;
import com.santander.scib.creame.filter.service.adapters.dataaccess.entity.FilterEntity;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import org.springframework.stereotype.Component;

@Component
public class FilterDataAccessMapper {

    public FilterEntity filterToFilterEntity(Filter filter){
        return FilterEntity.builder()
                .filterId(filter.getId().getValue())
                .excessId(filter.getExcessId().getValue())
                .processTimestamp(filter.getProcessTimestamp())
                .filterStatus(filter.getFilterStatus())
                .filtersMatching(filter.getFiltersMatching())
                .build();
    }

    public Filter filterEntityToFilter(FilterEntity filterEntity){
        return Filter.builder()
                .filterId(new FilterId(filterEntity.getFilterId()))
                .excessId(new ExcessId(filterEntity.getExcessId()))
                .processTimestamp(filterEntity.getProcessTimestamp())
                .filterStatus(filterEntity.getFilterStatus())
                .filtersMatching(filterEntity.getFiltersMatching())
                .build();
    }
}
