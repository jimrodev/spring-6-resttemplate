package com.santander.scib.creame.filter.service.adapters.api.web.fn;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.validation.ValidationHandler;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterResponse;
import com.santander.scib.creame.filter.service.domain.application.ports.input.service.FilterApplicationService;
import org.springframework.aot.hint.annotation.RegisterReflectionForBinding;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Validator;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Component
public class FilterHandler {
    private final FilterApplicationService filterApplicationService;

    private final ValidationHandler<FilterRequest, Validator> filterValidator;

    public FilterHandler(FilterApplicationService filterApplicationService,
                         @Qualifier("FunctionalEndPointValidator") Validator validator) {
        this.filterApplicationService = filterApplicationService;
        this.filterValidator = new ValidationHandler<FilterRequest, Validator>(FilterRequest.class, validator);
   }

    @RegisterReflectionForBinding(FilterRequest.class)
    public Mono<ServerResponse> applyFilter(final ServerRequest request){

        ContextMessage context = ContextMessage.builder()
                .messageType(FilterRequest.class.getTypeName())   // FULL QUALIFIER ID: com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest
                .inboundTransportType("https://")
                .inboundTransportLocation(FilterRouterConfig.FILTER_PATH)
                .build();

        return request.bodyToMono(FilterRequest.class)
                .doOnNext(this.filterValidator::validate)
                .flatMap(filterRequest ->  ServerResponse
                        .ok()
                        .header("location", UriComponentsBuilder.fromPath(FilterRouterConfig.FILTER_PATH_ID).build(filterRequest.getExcessId()).toString())
                        .body(Mono.just(filterApplicationService.apply(filterRequest, context)), FilterResponse.class));
                        //.bodyValue(excessApplicationService.create(excessRequest)));
    }
}
