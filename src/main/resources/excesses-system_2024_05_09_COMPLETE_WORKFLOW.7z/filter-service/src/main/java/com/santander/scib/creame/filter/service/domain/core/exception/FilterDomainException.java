package com.santander.scib.creame.filter.service.domain.core.exception;

import com.santander.scib.creame.excesses.domain.exception.DomainException;

public class FilterDomainException extends DomainException {

    public FilterDomainException(String message) {
        super(message);
    }

    public FilterDomainException(String message, Throwable cause) {
        super(message, cause);
    }
}
