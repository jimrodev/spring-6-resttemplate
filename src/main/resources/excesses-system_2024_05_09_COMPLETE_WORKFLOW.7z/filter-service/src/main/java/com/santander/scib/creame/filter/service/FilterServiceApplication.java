package com.santander.scib.creame.filter.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableJpaRepositories(basePackages = { "com.santander.scib.creame.excesses.application.outbox", "com.santander.scib.creame.filter.service.adapters.dataaccess" })
@EntityScan(basePackages = { "com.santander.scib.creame.excesses.application.outbox", "com.santander.scib.creame.filter.service.adapters.dataaccess"})
@SpringBootApplication(scanBasePackages = {"com.santander.scib.creame.excesses", "com.santander.scib.creame.filter"})
@EnableAsync
public class FilterServiceApplication {
    public static void main(String[] args) {
      SpringApplication.run(FilterServiceApplication.class, args);
    }
}
