package com.santander.scib.creame.filter.service.domain.application;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.filter.service.domain.application.dto.FilterRequest;
import com.santander.scib.creame.filter.service.domain.application.mapper.FilterDataMapper;
import com.santander.scib.creame.filter.service.domain.application.ports.output.repository.FilterRepository;
import com.santander.scib.creame.filter.service.domain.core.FilterDomainService;
import com.santander.scib.creame.filter.service.domain.core.entity.Filter;
import com.santander.scib.creame.filter.service.domain.core.entity.Rule;
import com.santander.scib.creame.filter.service.domain.core.event.FilterEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Component
public class FilterApplyHelper {

    private final FilterDomainService filterDomainService;
    private final FilterRepository filterRepository;

    private final FilterDataMapper filterDataMapper;

    public FilterApplyHelper(FilterDomainService filterDomainService,
                             FilterRepository filterRepository,
                             FilterDataMapper filterDataMapper) {
        this.filterDomainService = filterDomainService;
        this.filterRepository = filterRepository;
        this.filterDataMapper = filterDataMapper;
    }

    @Transactional
    public FilterEvent apply(FilterRequest filterRequest){
        Filter filter = filterDataMapper.filterRequestToFilter(filterRequest);

        // Retrieve Excess metadata

        // Retrieve Rules to apply (DB,FILE)
        List<String> rules = new ArrayList<>();
        Rule rule = Rule.builder()
                .rules(rules)
                .build();

        FilterEvent filterEvent = filterDomainService.apply(filter, rule);
        filterRepository.save(filter);

        return filterEvent;
    }

    @Transactional(readOnly = true)
    public Optional<Filter> findByExcessIdAndProcessTimestamp(ExcessId excessId, String processTimestamp) {

        return filterRepository.findByExcessIdAndProcessTimestamp(excessId,
                                                                 processTimestamp);
    }
}
