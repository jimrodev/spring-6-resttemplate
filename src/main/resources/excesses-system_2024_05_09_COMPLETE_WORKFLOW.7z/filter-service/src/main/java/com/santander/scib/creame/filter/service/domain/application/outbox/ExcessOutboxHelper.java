package com.santander.scib.creame.filter.service.domain.application.outbox;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.helper.CoordinatorHelper;
import com.santander.scib.creame.filter.service.domain.application.ports.output.repository.ExcessOutboxRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ExcessOutboxHelper extends CoordinatorHelper<ExcessOutboxRepository> {
    public ExcessOutboxHelper(@Value(Stakeholders.FILTER) final String eventSource,
                              @Value(Stakeholders.EXCESS) final String eventTarget,
                              @Value("#{Spools['excesses']}") final SpoolConfigData spoolConfigData,
                              ExcessOutboxRepository excessOutboxRepository) {
        super(eventSource,
              eventTarget,
              spoolConfigData,
              excessOutboxRepository);
    }
}
