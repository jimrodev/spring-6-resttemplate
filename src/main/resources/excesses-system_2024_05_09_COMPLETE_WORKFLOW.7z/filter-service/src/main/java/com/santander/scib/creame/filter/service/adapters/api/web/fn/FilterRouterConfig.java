package com.santander.scib.creame.filter.service.adapters.api.web.fn;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;

import static org.springframework.http.MediaType.APPLICATION_JSON;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;

@Configuration
@RequiredArgsConstructor
public class FilterRouterConfig {

    public static final String FILTER_PATH = "/api/v3/filter";
    public static final String FILTER_PATH_ID = FILTER_PATH + "/{id}";

    private final FilterHandler handler;

    @Bean
    public RouterFunction<ServerResponse> filterRoutes(){
        return route()
                .POST(FILTER_PATH, accept(APPLICATION_JSON), handler::applyFilter)
                .build();
    }
}
