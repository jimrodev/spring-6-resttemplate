package com.santander.scib.creame.filter.service.domain.core.event;

import com.santander.scib.creame.filter.service.domain.core.entity.Filter;

import java.time.ZonedDateTime;

public class FailedEvent extends FilterEvent{
    public FailedEvent(Filter filter,
                       ZonedDateTime createdAt) {
        super(filter, createdAt);
    }
}
