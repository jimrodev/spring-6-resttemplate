DROP TYPE IF EXISTS filter_status;
CREATE TYPE filter_status AS ENUM ('PENDING', 'FILTERED',  'UNFILTERED', 'FAILED');

DROP TABLE IF EXISTS excesses.filters;
CREATE TABLE excesses.filters
(
    filter_id uuid NOT NULL,
    excess_id VARCHAR NOT NULL,
    process_timestamp VARCHAR NOT NULL,
    filter_status filter_status NOT NULL,
    filters_matching jsonb,
    CONSTRAINT filter_pkey PRIMARY KEY (filter_id)
);

CREATE INDEX filter_excess_process_timestamp
    ON "excesses".filters
        (excess_id, process_timestamp);