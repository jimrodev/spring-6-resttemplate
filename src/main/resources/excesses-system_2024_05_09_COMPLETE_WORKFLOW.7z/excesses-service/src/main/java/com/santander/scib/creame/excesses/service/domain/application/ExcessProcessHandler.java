package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.service.domain.application.outbox.FilterOutboxHelper;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessResponse;
import com.santander.scib.creame.excesses.service.domain.application.mapper.ExcessDataMapper;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessAlertedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessCreatedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessResolvedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessUpdatedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.UUID;

@Slf4j
@Component
public class ExcessProcessHandler {
    private final ExcessProcessHelper excessProcessHelper;
    private final FilterOutboxHelper filterOutboxHelper;
    private final ExcessDataMapper excessDataMapper;

    public ExcessProcessHandler(ExcessProcessHelper excessProcessHelper,
                                FilterOutboxHelper filterOutboxHelper,
                                ExcessDataMapper excessDataMapper) {
        this.excessProcessHelper = excessProcessHelper;
        this.filterOutboxHelper = filterOutboxHelper;
        this.excessDataMapper = excessDataMapper;
    }

    @Transactional
    public ExcessResponse create(ExcessRequest excessRequest, ContextMessage contextRequest){
        // BEGIN - OUTBOX ATOMIC SCOPE {}

        // COMMON
        ExcessCreatedEvent excessCreatedEvent = excessProcessHelper.persistExcess(excessRequest);
        log.info("Excess is created with id: {}", excessCreatedEvent.getEntity().getId().getValue());

        // OUTBOX IMPLEMENTATION (SAGA CORRELATION - STARTED)
        UUID outboxId = UUID.randomUUID();  // Outbox Id
        UUID sagaId = UUID.randomUUID();    // Interchange Id for the saga flow

        // Load context properties - Send by headers (Event Bus)
        contextRequest.setMessageId(excessCreatedEvent.getId());
        contextRequest.setInterchangeId(sagaId);
        contextRequest.setEventSource(Stakeholders.EXCESS);

        // SAVE Outbox Message (Event Message, Message Context)
        filterOutboxHelper.saveCoordinatorMessage(sagaId,
                                                  SagaStatus.STARTED,
                                                  outboxId,
                                                  OutboxStatus.STARTED,
                                                  excessCreatedEvent,
                                                  excessDataMapper::ExcessToExcessRequest,
                                                  contextRequest);

        // COMMON
        return excessDataMapper.ExcessToExcessResponse(excessCreatedEvent.getEntity());

        // END - OUTBOX ATOMIC SCOPE {}
    }

    @Transactional
    public ExcessResponse update(ExcessRequest excessRequest, ContextMessage contextRequest){

        ExcessUpdatedEvent excessUpdatedEvent = excessProcessHelper.updateExcess(excessRequest);
        log.info("Excess is updated with id: {}", excessUpdatedEvent.getEntity().getId().getValue());

        return excessDataMapper.ExcessToExcessResponse(excessUpdatedEvent.getEntity());
    }

    @Transactional
    public ExcessResponse solve(ExcessRequest excessRequest, ContextMessage contextRequest){

        ExcessResolvedEvent excessResolvedEvent = excessProcessHelper.solveExcess(excessRequest);
        log.info("Excess is solved with id: {}", excessResolvedEvent.getEntity().getId().getValue());

        return excessDataMapper.ExcessToExcessResponse(excessResolvedEvent.getEntity());
    }

    @Transactional
    public ExcessResponse alert(ExcessRequest excessRequest, ContextMessage contextRequest){
        // REVIEW (Return alert condition)
        // CREAR UN EVENTO A SER PROCESADO POR EL MÓDULO DE ALERTAS? A
        // CREAR UN ETADO QUE IDENTIFIQUE QUE SE HA PRODUCIDO UNA ALERTA??

        ExcessAlertedEvent excessAlertedEvent = excessProcessHelper.alertExcess(excessRequest, contextRequest);

        log.info("Excess is alerted with id: {}", excessAlertedEvent.getEntity().getId().getValue());

        return excessDataMapper.ExcessToExcessResponse(excessAlertedEvent.getEntity());
    }

    public ExcessOperation computeOperation(ExcessRequest excessRequest)
    {
        Optional<Excess> excessFound = excessProcessHelper.findById(
                                            new ExcessId(excessRequest.getExcessId()));
        // NOT FOUND (DB)
        if(excessFound.isEmpty()) {
            // NEW (BEGIN DATE equals PROCESS DATE)
            if (excessRequest.getExcessBeginDate().equals(excessRequest.getExcessDetail().getProcessDate()) &&
                    excessRequest.getExcessBeginTimestamp().equals(excessRequest.getExcessDetail().getProcessTimestamp())) {
                return ExcessOperation.NEW;

            } else {
                // REVIEW !!
                return ExcessOperation.ALERT;
            }
        }
        // FOUND (DB)
        // UPDATE (BEGIN DATE not equals PROCESS DATE and END DATE null)
        else if (!excessRequest.getExcessBeginDate().equals(excessRequest.getExcessDetail().getProcessDate())
                    &&
                !excessRequest.getExcessBeginTimestamp().equals(excessRequest.getExcessDetail().getProcessTimestamp())
                    &&
                (excessRequest.getExcessEndDate() == null)
                    &&
                (excessRequest.getExcessEndTimestamp() == null)) {
            return ExcessOperation.UPDATE;
        }
        // SOLVE (END DATE equals PROCESS DATE)
        else if (((excessRequest.getExcessEndDate() != null)
                    &&
                excessRequest.getExcessEndDate().equals(excessRequest.getExcessDetail().getProcessDate()))
                    &&
                ((excessRequest.getExcessEndTimestamp() != null)
                    &&
                excessRequest.getExcessEndTimestamp().equals(excessRequest.getExcessDetail().getProcessTimestamp()))) {
            return ExcessOperation.SOLVED;

        }
        // REVIEW !!
        return ExcessOperation.ALERT;
    }
}
