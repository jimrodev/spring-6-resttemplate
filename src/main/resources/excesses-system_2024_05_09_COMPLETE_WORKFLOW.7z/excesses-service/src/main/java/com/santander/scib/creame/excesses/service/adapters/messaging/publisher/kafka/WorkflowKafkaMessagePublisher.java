package com.santander.scib.creame.excesses.service.adapters.messaging.publisher.kafka;

import com.santander.scib.creame.avro.models.WorkflowRequestAvroModel;
import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.OutboxCommonHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaOutboxMessagePublisher;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaProducerHelper;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.WorkflowMessagingDataMapper;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.WorkflowRequest;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.message.publisher.WorkflowMessagePublisher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.function.BiConsumer;

@Slf4j
@Component
public class WorkflowKafkaMessagePublisher extends KafkaOutboxMessagePublisher<ExcessRequest, WorkflowRequestAvroModel, CoordinatorMessage>
                                           implements WorkflowMessagePublisher {

    private final WorkflowMessagingDataMapper workflowMessagingDataMapper;
    private final String topicName;

    public WorkflowKafkaMessagePublisher(WorkflowMessagingDataMapper workflowMessagingDataMapper,
                                         KafkaProducer<String, WorkflowRequestAvroModel> kafkaProducer,
                                         KafkaProducerHelper kafkaProducerHelper,
                                         @Value("#{@kafkaTopics['workflow-request']}") String topicName){
        super(kafkaProducer, kafkaProducerHelper);
        this.workflowMessagingDataMapper = workflowMessagingDataMapper;
        this.topicName = topicName;
    }

    @Override
    public void publish(CoordinatorMessage coordinatorMessage, BiConsumer<CoordinatorMessage, OutboxStatus> outboxCallback) {
        // Set output context properties
        ContextMessage context = OutboxCommonHelper.deserializePayload(coordinatorMessage.getContext(),
                                                                       ContextMessage.class);
        // Message type
        context.setMessageType(WorkflowRequest.class.getTypeName());
        // Outbound transport properties
        context.setOutboundTransportType("Kafka://");
        context.setOutboundTransportLocation(topicName);

        coordinatorMessage.setContext(OutboxCommonHelper.serializeContext(coordinatorMessage.getOutboxId(),
                                                                         context));
        // Publish message (Event bus)
        publish(coordinatorMessage,
                outboxCallback,
                this.workflowMessagingDataMapper::excessRequestToWorkflowRequestAvroModel,
                this.topicName);
    }
}
