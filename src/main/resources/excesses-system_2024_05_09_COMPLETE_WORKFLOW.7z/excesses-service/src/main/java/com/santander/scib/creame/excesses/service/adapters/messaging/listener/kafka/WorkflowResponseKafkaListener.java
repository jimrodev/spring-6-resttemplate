package com.santander.scib.creame.excesses.service.adapters.messaging.listener.kafka;

import com.santander.scib.creame.avro.models.WorkflowResponseAvroModel;
import com.santander.scib.creame.avro.models.WorkflowStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.helper.ContextHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumerHelper;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaContextHelper;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.WorkflowMessagingDataMapper;
import com.santander.scib.creame.excesses.service.domain.application.dto.WorkflowResponse;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.WorkflowResponseMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class WorkflowResponseKafkaListener implements KafkaConsumer<WorkflowResponseAvroModel> {

    private final WorkflowResponseMessageListener workflowResponseMessageListener;
    private final WorkflowMessagingDataMapper workflowMessagingDataMapper;
    private final String topicName;

    public WorkflowResponseKafkaListener(WorkflowResponseMessageListener workflowResponseMessageListener,
                                         WorkflowMessagingDataMapper workflowMessagingDataMapper,
                                         @Value("#{@kafkaTopics['workflow-response']}") String topicName) {
        this.workflowResponseMessageListener = workflowResponseMessageListener;
        this.workflowMessagingDataMapper = workflowMessagingDataMapper;
        this.topicName = topicName;
    }

    @Override
    @KafkaListener(
            id = "workflow-listener",
            topics = "#{@kafkaTopics['workflow-response']}",
            containerFactory = "#{@kafkaListenerContainerFactories['workflow']}",
            idIsGroup = false
    )
    public void receivedBatch(List<Message<WorkflowResponseAvroModel>> messages) {
        List<Message<WorkflowResponseAvroModel>> sanitizedMessages = KafkaConsumerHelper.sanitizedMessages(messages);
        sanitizedMessages.forEach(workflowResponseAvroModelMessage -> {
            try {
                // Load Message context (Kafka custom headers)
                ContextMessage context = KafkaContextHelper.getContextMessage(workflowResponseAvroModelMessage.getHeaders());
                ContextHelper.clean(context, ContextHelper.ContextSection.TRANSPORT);
                // MessageType
                context.setMessageType(WorkflowResponse.class.getTypeName());
                // Transport properties
                context.setInboundTransportType("kafka://");
                context.setInboundTransportLocation(topicName);

                WorkflowStatus workflowStatus = workflowResponseAvroModelMessage.getPayload().getWorkflowStatus();
                switch (workflowStatus) {
                    case ASSIGNED -> {
                        workflowResponseMessageListener.assigned(
                                workflowMessagingDataMapper.workflowResponseAvroModelToWorkflowResponse(
                                        workflowResponseAvroModelMessage.getPayload()
                                ),
                                context);
                    }
                    case FAILED -> {
                        workflowResponseMessageListener.failed(
                                workflowMessagingDataMapper.workflowResponseAvroModelToWorkflowResponse(
                                        workflowResponseAvroModelMessage.getPayload()
                                ),
                                context);
                    }
                }

            } catch (OptimisticLockingFailureException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught optimistic locking exception in WorkflowResponseKafkaListener for excess id: {}",
                        workflowResponseAvroModelMessage.getPayload().getExcessId());
            }
        });
    }
}