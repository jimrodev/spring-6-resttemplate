package com.santander.scib.creame.excesses.service.domain.application.saga;

import com.santander.scib.creame.excesses.application.outbox.OutboxStatus;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.saga.SagaStatus;
import com.santander.scib.creame.excesses.application.saga.SagaStep;
import com.santander.scib.creame.excesses.service.domain.application.dto.WorkflowResponse;
import com.santander.scib.creame.excesses.service.domain.application.outbox.FilterOutboxHelper;
import com.santander.scib.creame.excesses.service.domain.application.outbox.WorkflowOutboxHelper;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessRepository;
import com.santander.scib.creame.excesses.service.domain.core.ExcessDomainService;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.event.ExcessAssignedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Slf4j
@Component
public class WorkflowSagaHandler implements SagaStep<WorkflowResponse, ContextMessage> {

    private final ExcessDomainService excessDomainService;
    private final ExcessRepository excessRepository;
    private final FilterOutboxHelper filterOutboxHelper;
    private final WorkflowOutboxHelper workflowOutboxHelper;
    private final SagaHelper sagaHelper;
    public WorkflowSagaHandler(ExcessDomainService excessDomainService,
                               ExcessRepository excessRepository,
                               FilterOutboxHelper filterOutboxHelper,
                               WorkflowOutboxHelper workflowOutboxHelper,
                               SagaHelper sagaHelper) {
        this.excessDomainService = excessDomainService;
        this.excessRepository = excessRepository;
        this.filterOutboxHelper = filterOutboxHelper;
        this.workflowOutboxHelper = workflowOutboxHelper;
        this.sagaHelper = sagaHelper;
    }

    @Override
    @Transactional
    public void process(WorkflowResponse workflowResponse, ContextMessage context) {
        // SAGA STEP - Process (Workflow response)
        // BEGIN - OUTBOX ATOMIC SCOPE {}

        Optional<CoordinatorMessage> coordinatorMessageFound =
                workflowOutboxHelper.getOutboxMessageBySagaIdAndSagaStatus(context.getInterchangeId(),
                                                                           SagaStatus.CONTINUATION);

        // Contingency Actions(1)
        // If not found an outbox entry with interchangeId and SagaStatus.CONTINUATION
        // means is a duplicate message!
        if(coordinatorMessageFound.isEmpty()){
            log.info("A Workflow response message with saga id: {} is already processed!", context.getInterchangeId());
            return;
        }

        // UPDATE STATUS (Excess, OUTBOX, SAGA)
        CoordinatorMessage coordinatorMessage = coordinatorMessageFound.get();

        // UPDATE the Excess status (ASSIGNED)
        ExcessAssignedEvent excessAssignedEvent = completeWorkflowForExcess(workflowResponse);

        // Contingency Actions(2)
        // When receive a response of Workflow Service but the outbox status is FAILED
        // Kafka callback was made with FAILED status
        // COMPlETED OUBOX STATUS
        coordinatorMessage.setOutboxStatus(OutboxStatus.COMPLETED);

        // UPDATE SAGA STATUS (COMPLETED)
        coordinatorMessage.setSagaStatus(sagaHelper
                                        .excessStatusToSagaStatus(excessAssignedEvent.getEntity().getExcessStatus()));

        // REVISAR
        // Caught optimistic locking exception in WorkflowResponseKafkaListener ??
        // Contingency Actions(2)
        // workflowOutboxHelper.updateCoordinatorMessage(coordinatorMessage);

        // CLOSE SAGA LLT (Complete all Saga Steps)
        workflowOutboxHelper.updateOutboxMessageBySagaIdAndSagaStatus(context.getInterchangeId(),
                                                                      List.of(SagaStatus.CONTINUATION),
                                                                      SagaStatus.COMPLETED);

        // END - OUTBOX ATOMIC SCOPE {}
    }

    @Override
    @Transactional
    public void compensation(WorkflowResponse workflowResponse, ContextMessage context) {
        // SAGA STEP - Compensation (Workflow response)
        // BEGIN - OUTBOX ATOMIC SCOPE {}

        Optional<CoordinatorMessage> coordinatorMessageFound =
                workflowOutboxHelper.getOutboxMessageBySagaIdAndSagaStatus(context.getInterchangeId(),
                                                                           SagaStatus.CONTINUATION);

        // Contingency Actions(1)
        // If not found an outbox entry with interchangeId and SagaStatus.CONTINUATION
        // means is a duplicate message!
        if(coordinatorMessageFound.isEmpty()){
            log.info("A Workflow response message with saga id: {} is already compensated!", context.getInterchangeId());
            return;
        }

        // Compensation
        // UPDATE STATUS (Excess, OUTBOX, SAGA)
        CoordinatorMessage coordinatorMessage = coordinatorMessageFound.get();

        // UPDATE the Excess status (FAILED)
        ExcessAssignedEvent excessAssignedEvent = completeWorkflowForExcess(workflowResponse);

        // Contingency Actions(2)
        // When receive a response of Workflow Service but the outbox status is FAILED
        // Kafka callback was made with FAILED status
        // COMPlETED OUBOX STATUS
        coordinatorMessage.setOutboxStatus(OutboxStatus.COMPLETED);

        // UPDATE SAGA STATUS (FAILED)
        coordinatorMessage.setSagaStatus(sagaHelper
                .excessStatusToSagaStatus(excessAssignedEvent.getEntity().getExcessStatus()));

        workflowOutboxHelper.updateCoordinatorMessage(coordinatorMessage);

        // END - OUTBOX ATOMIC SCOPE {}
    }

    private ExcessAssignedEvent completeWorkflowForExcess(WorkflowResponse workflowResponse) {
        log.info("Completing workflow for excess id: {}", workflowResponse.getExcessId());
        Excess excess = sagaHelper.findExcess(workflowResponse.getExcessId());
//      ExcessDetail excessDetail = sagaHelper.findExcessDetail(workflowResponse.getExcessId(),
//                                                                workflowResponse.getProcessTimestamp());
//      excess.setExcessDetail(excessDetail);

        ExcessAssignedEvent excessAssignedEvent = excessDomainService.assign(excess,
                                                                             workflowResponse.getWorkflowStatus());
        excessRepository.update(excess);
        return excessAssignedEvent;
    }
}
