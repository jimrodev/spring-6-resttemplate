package com.santander.scib.creame.excesses.service.adapters.dataaccess.entity;

import com.google.common.base.Objects;
import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExcessDetailEntityId implements Serializable {
    private String excessId;
    private String processTimestamp;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExcessDetailEntityId that = (ExcessDetailEntityId) o;
        return Objects.equal(excessId, that.excessId) && Objects.equal(processTimestamp, that.processTimestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(excessId, processTimestamp);
    }
}
