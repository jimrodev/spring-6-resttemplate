package com.santander.scib.creame.excesses.service.domain.application.ports.output.message.publisher;

import com.santander.scib.creame.excesses.application.outbox.dto.CoordinatorMessage;
import com.santander.scib.creame.excesses.application.outbox.OutboxMessagePublisher;

public interface FilterMessagePublisher extends OutboxMessagePublisher<CoordinatorMessage> {
}
