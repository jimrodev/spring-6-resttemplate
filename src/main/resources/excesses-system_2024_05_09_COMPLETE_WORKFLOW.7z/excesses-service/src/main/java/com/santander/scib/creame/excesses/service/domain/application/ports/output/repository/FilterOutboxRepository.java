package com.santander.scib.creame.excesses.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.application.outbox.repository.CoordinatorRepository;

public interface FilterOutboxRepository extends CoordinatorRepository {
}
