package com.santander.scib.creame.excesses.service.domain.core;

import com.santander.scib.creame.excesses.domain.valueobject.FilterStatus;
import com.santander.scib.creame.excesses.domain.valueobject.WorkflowStatus;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.event.*;

public interface ExcessDomainService {

    ExcessCreatedEvent create(Excess excess);
    ExcessUpdatedEvent update(Excess excess);
    ExcessResolvedEvent solve(Excess excess);
    ExcessFilteredEvent filter(Excess excess, FilterStatus filterStatus);
    ExcessAssignedEvent assign(Excess excess, WorkflowStatus workflowStatus);

}
