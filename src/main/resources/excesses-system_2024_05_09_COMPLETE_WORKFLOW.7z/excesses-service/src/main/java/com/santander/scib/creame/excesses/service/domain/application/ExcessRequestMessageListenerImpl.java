package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.ExcessRequestMessageListener;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;

@Slf4j
@Service
public class ExcessRequestMessageListenerImpl implements ExcessRequestMessageListener {
    private final ExcessProcessHandler excessProcessHandler;

    public ExcessRequestMessageListenerImpl(ExcessProcessHandler excessProcessHandler) {
        this.excessProcessHandler = excessProcessHandler;
    }

    @Override
    public void process(ExcessRequest excessRequest, ContextMessage context) {
        switch (excessProcessHandler.computeOperation(excessRequest)){
            case NEW -> excessProcessHandler.create(excessRequest, context);
            case UPDATE -> excessProcessHandler.update(excessRequest, context);
            case SOLVED -> excessProcessHandler.solve(excessRequest, context);
            case ALERT -> excessProcessHandler.alert(excessRequest, context);
        };
    }
}
