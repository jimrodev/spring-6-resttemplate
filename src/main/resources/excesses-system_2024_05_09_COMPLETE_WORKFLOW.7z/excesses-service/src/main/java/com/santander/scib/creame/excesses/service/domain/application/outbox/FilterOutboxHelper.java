package com.santander.scib.creame.excesses.service.domain.application.outbox;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.outbox.config.SpoolConfigData;
import com.santander.scib.creame.excesses.application.outbox.helper.CoordinatorHelper;
import com.santander.scib.creame.excesses.application.outbox.Stakeholders;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.FilterOutboxRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class FilterOutboxHelper extends CoordinatorHelper<FilterOutboxRepository> {
    public FilterOutboxHelper(@Value(Stakeholders.EXCESS) final String eventSource,
                              @Value(Stakeholders.FILTER) final String eventTarget,
                              @Value("#{Spools['filter']}") final SpoolConfigData spoolConfigData,
                              FilterOutboxRepository filterOutboxRepository) {
        super(eventSource,
              eventTarget,
              spoolConfigData,
              filterOutboxRepository);
    }
}
