package com.santander.scib.creame.excesses.service.adapters.dataaccess.mapper;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessDetailId;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessDetailEntity;
import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.ExcessEntity;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;
import org.springframework.stereotype.Component;

@Component
public class ExcessDataAccessMapper {

    public ExcessEntity excessToExcessEntity(Excess excess){
        return ExcessEntity.builder()
                .excessId(excess.getId().getValue())
                .metricType(excess.getMetricType())
                .excessMetric(excess.getExcessMetric())
                .excessBeginDate(excess.getExcessBeginDate())
                .excessBeginTimestamp(excess.getExcessBeginTimestamp())
                .excessEndDate(excess.getExcessEndDate())
                .excessEndTimestamp(excess.getExcessEndTimestamp())
                .limitInternalKey(excess.getLimitInternalKey())
                .excessType(excess.getExcessType())
                .excessStatus(excess.getExcessStatus())
                .build();
    }

    public Excess excessEntityToExcess(ExcessEntity excessEntity){
        return Excess.builder()
                .excessId(new ExcessId(excessEntity.getExcessId()))
                .metricType(excessEntity.getMetricType())
                .excessMetric(excessEntity.getExcessMetric())
                .excessBeginDate(excessEntity.getExcessBeginDate())
                .excessBeginTimestamp(excessEntity.getExcessBeginTimestamp())
                .excessEndDate(excessEntity.getExcessEndDate())
                .excessEndTimestamp(excessEntity.getExcessEndTimestamp())
                .limitInternalKey(excessEntity.getLimitInternalKey())
                .excessType(excessEntity.getExcessType())
                .excessStatus(excessEntity.getExcessStatus())
                .build();
    }

    public ExcessDetailEntity excessDetailToExcessDetailEntity(ExcessDetail excessDetail) {
        return ExcessDetailEntity.builder()
                .excessId(excessDetail.getId().getKey(0))
                .processTimestamp(excessDetail.getId().getKey(1))
                .processDate(excessDetail.getProcessDate())
                .limitOrigin(excessDetail.getLimitOrigin())
                .limitShortName(excessDetail.getLimitShortName())
                .period(excessDetail.getPeriod())
                .limitCurrency(excessDetail.getLimitCurrency())
                .limitAmount(excessDetail.getLimitAmount())
                .used(excessDetail.getUsed())
                .excessReason(excessDetail.getExcessReason())
                .metadata(excessDetail.getMetadata())
                .build();
    }

    public ExcessDetail excessDetailEntityToExcessDetail(ExcessDetailEntity excessDetailEntity) {
        return ExcessDetail.builder()
                .excessDetailId(new ExcessDetailId(excessDetailEntity.getExcessId(),excessDetailEntity.getProcessTimestamp()))
                .processDate(excessDetailEntity.getProcessDate())
                .limitOrigin(excessDetailEntity.getLimitOrigin())
                .limitShortName(excessDetailEntity.getLimitShortName())
                .period(excessDetailEntity.getPeriod())
                .limitCurrency(excessDetailEntity.getLimitCurrency())
                .limitAmount(excessDetailEntity.getLimitAmount())
                .used(excessDetailEntity.getUsed())
                .excessReason(excessDetailEntity.getExcessReason())
                .metadata(excessDetailEntity.getMetadata())
                .build();
    }
}
