package com.santander.scib.creame.excesses.service.adapters.dataaccess.repository;

import com.santander.scib.creame.excesses.service.adapters.dataaccess.entity.PartitionEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PartitionJpaRepository extends JpaRepository<PartitionEntity, String> {
    //Optional<PartitionEntity> findByPartitionId(String partitionId);
}
