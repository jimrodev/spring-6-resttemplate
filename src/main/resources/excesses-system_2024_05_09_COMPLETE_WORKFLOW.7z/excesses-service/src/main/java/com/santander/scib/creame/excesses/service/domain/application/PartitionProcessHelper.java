package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.receive.ExcessesSnapshotReceive;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessDetailRepository;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessRepository;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.FilterOutboxRepository;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.PartitionRepository;
import com.santander.scib.creame.excesses.service.domain.core.PartitionDomainService;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionAlertedEvent;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.mapper.PartitionDataMapper;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionProcessedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionReprocessedEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static com.santander.scib.creame.excesses.domain.DomainConstants.UTC;

@Slf4j
@Component
public class PartitionProcessHelper {

    private final PartitionDomainService partitionDomainService;
    private final PartitionRepository partitionRepository;
    private final PartitionDataMapper partitionDataMapper;
    private final ExcessesSnapshotReceive excessesSnapshotReceive;
    private final ExcessProcessHandler excessProcessHandler;

    private final ExcessRepository excessRepository;
    private final ExcessDetailRepository excessDetailRepository;
    private final FilterOutboxRepository filterOutboxRepository;

    public PartitionProcessHelper(PartitionDomainService partitionDomainService,
                                  PartitionRepository partitionRepository,
                                  PartitionDataMapper partitionDataMapper,
                                  ExcessesSnapshotReceive excessesSnapshotReceive,
                                  ExcessProcessHandler excessProcessHandler,
                                  ExcessRepository excessRepository,
                                  ExcessDetailRepository excessDetailRepository,
                                  FilterOutboxRepository filterOutboxRepository) {
        this.partitionDomainService = partitionDomainService;
        this.partitionRepository = partitionRepository;
        this.partitionDataMapper = partitionDataMapper;
        this.excessesSnapshotReceive = excessesSnapshotReceive;
        this.excessProcessHandler = excessProcessHandler;
        this.excessRepository = excessRepository;
        this.excessDetailRepository = excessDetailRepository;
        this.filterOutboxRepository = filterOutboxRepository;
    }

    @Transactional
    public PartitionProcessedEvent process(PartitionRequest partitionRequest, ContextMessage context){

        Partition partition = partitionDataMapper.PartitionRequestToPartition(partitionRequest);

        PartitionProcessedEvent partitionEvent = partitionDomainService.process(partition);

        partitionRepository.save(partition);

        // PROCESS Excess set (Imput receive port -> s3 adapter )
        Set<ExcessRequest> excesses = excessesSnapshotReceive.processFile(partition.getId().getValue(), context);

        AtomicInteger sequenceNumber = new AtomicInteger(1);
        excesses.forEach(excess -> {
            context.setBatchSequenceNumber(String.valueOf(sequenceNumber.getAndIncrement()));
            excessProcessHandler.create(excess,context);
        });

        return partitionEvent;
    }

    public void processBatch(final Set<ExcessRequest> excesses, ContextMessage context){


        AtomicInteger sequenceNumber = new AtomicInteger(1);

        excesses.forEach(excess -> {
            context.setBatchSequenceNumber(String.valueOf(sequenceNumber.getAndIncrement()));
            excessProcessHandler.create(excess,context);
        });
        // Bulk performance
        excessRepository.flush();;
        excessDetailRepository.flush();
        filterOutboxRepository.flush();
    }


    @Transactional
    public PartitionReprocessedEvent reprocess(PartitionRequest partitionRequest, ContextMessage context){

        Optional<Partition> partitionFound = partitionRepository.findByPartitionId(
                new PartitionId(partitionRequest.getPartitionId()));

        Partition partition = Partition.builder()
                .partitionId(new PartitionId(partitionRequest.getPartitionId()))
                .partitionStatus(partitionFound.map(Partition::getPartitionStatus).orElse(null))
                .build();

        PartitionReprocessedEvent partitionEvent = partitionDomainService.reprocess(partition);

        partitionRepository.save(partition);

        // REPROCESS Excess set (Imput receive port -> s3 adapter )
        Set<ExcessRequest> excesses = excessesSnapshotReceive.processFile(partition.getId().getValue(), context);
        AtomicInteger sequenceNumber = new AtomicInteger(1);
        excesses.forEach(excess -> {
            context.setBatchSequenceNumber(String.valueOf(sequenceNumber.getAndIncrement()));
            excessProcessHandler.create(excess,context);
        });
        // Bulk performance
        excessRepository.flush();;
        excessDetailRepository.flush();;

        return partitionEvent;
    }

    @Transactional
    public PartitionAlertedEvent alert(PartitionRequest partitionRequest, ContextMessage context) {

        // ALERT
        // REVIEW CREAR UN EVENTO QUE VAYA AL MODULO DE ALERTAS?
        // CREAR UN ESTADO QUE INDIQUE QUE SE HA PRODUCIDO LA ALERTA?
        Optional<Partition> partitionFound = partitionRepository.findByPartitionId(
                                                     new PartitionId(partitionRequest.getPartitionId()));

        Partition partition = Partition.builder()
                                        .partitionId(new PartitionId(partitionRequest.getPartitionId()))
                                        .partitionStatus(partitionFound.map(Partition::getPartitionStatus).orElse(null))
                                        .build();

        return new PartitionAlertedEvent(partition,
                ZonedDateTime.now(ZoneId.of(UTC)));

    }
}
