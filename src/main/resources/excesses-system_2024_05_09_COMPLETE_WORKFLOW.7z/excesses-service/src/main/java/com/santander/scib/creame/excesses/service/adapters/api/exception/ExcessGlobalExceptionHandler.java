package com.santander.scib.creame.excesses.service.adapters.api.exception;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.santander.scib.creame.excesses.application.exception.GlobalExceptionHandler;
import com.santander.scib.creame.excesses.application.exception.ResponseBodyError;
import com.santander.scib.creame.excesses.domain.DomainConstants;
import com.santander.scib.creame.excesses.service.domain.core.exception.ExcessDomainException;
import com.santander.scib.creame.excesses.service.domain.core.exception.ExcessNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.time.ZoneId;
import java.time.ZonedDateTime;

@Slf4j
@ControllerAdvice
public class ExcessGlobalExceptionHandler extends GlobalExceptionHandler {

    public ExcessGlobalExceptionHandler(ObjectMapper objectMapper) {
        super(objectMapper);
    }

    @ResponseBody
    @ExceptionHandler(value = {ExcessDomainException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<ResponseBodyError> handleException(ExcessDomainException excessDomainException) {
        log.error(excessDomainException.getMessage(), excessDomainException);
        return ResponseEntity
                .badRequest()
                .body(
                        ResponseBodyError.builder()
                            .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                            .status(HttpStatus.BAD_REQUEST.value())
                            .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                            .message(excessDomainException.getMessage())
                            .build());
    }

    @ResponseBody
    @ExceptionHandler(value = {ExcessNotFoundException.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ResponseEntity<ResponseBodyError> handleException(ExcessNotFoundException excessNotFoundException) {
        log.error(excessNotFoundException.getMessage(), excessNotFoundException);
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(
                        ResponseBodyError.builder()
                                .timestamp(ZonedDateTime.now(ZoneId.of(DomainConstants.UTC)))
                                .status(HttpStatus.NOT_FOUND.value())
                                .error(HttpStatus.NOT_FOUND.getReasonPhrase())
                                .message(excessNotFoundException.getMessage())
                                .build());
    }
}
