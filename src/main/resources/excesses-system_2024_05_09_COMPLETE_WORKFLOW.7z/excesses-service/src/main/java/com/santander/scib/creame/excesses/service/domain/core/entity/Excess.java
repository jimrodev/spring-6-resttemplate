package com.santander.scib.creame.excesses.service.domain.core.entity;

import com.santander.scib.creame.excesses.domain.entity.AggregateRoot;
import com.santander.scib.creame.excesses.domain.valueobject.*;

public class Excess  extends AggregateRoot<ExcessId> {

    private final MetricType metricType;
    private final ExcessMetric excessMetric;
    private final String excessBeginDate;
    private final String excessBeginTimestamp;
    private final String excessEndDate;
    private final String excessEndTimestamp;

    private final String limitInternalKey;

    private ExcessType excessType;
    private ExcessStatus excessStatus;

    private ExcessDetail excessDetail;

    private Excess(Builder builder) {
        super.setId(builder.excessId);
        metricType = builder.metricType;
        excessMetric = builder.excessMetric;
        excessBeginDate = builder.excessBeginDate;
        excessBeginTimestamp = builder.excessBeginTimestamp;
        excessEndDate = builder.excessEndDate;
        excessEndTimestamp = builder.excessEndTimestamp;
        limitInternalKey = builder.limitInternalKey;
        excessType = builder.excessType;
        excessStatus = builder.excessStatus;
        excessDetail = builder.excessDetail;
    }

    public void process(){
        // HERE All FUNCTIONALITY OF PROCESS OPERATION
    }

    // Add to AgregetRoot class an override here??
    public void initialize(){
        excessType = ExcessType.UNDER_REVIEW;
        excessStatus = ExcessStatus.PENDING;
    }
    public void validate(){
        // HERE All FUNCTIONALITY OF VALIDATE OPERATION
    };

    public void create(){
        initialize();
        // HERE All FUNCTIONALITY OF CREATE OPERATION

    }

    public void update(){
        validate();
        // HERE All FUNCTIONALITY OF UPDATE OPERATION

    }

    public void solve(){
        validate();
        // HERE All FUNCTIONALITY OF SOLVE OPERATION
        excessStatus = ExcessStatus.RESOLVED;

    }

    public void filter(FilterStatus filterStatus){
        // HERE All FUNCTIONALITY OF FILTER OPERATION
        validate();
        switch (filterStatus)
        {
            case FILTERED   -> setExcessStatus(ExcessStatus.FILTERED);
            case UNFILTERED -> setExcessStatus(ExcessStatus.UNFILTERED);
            case FAILED     -> setExcessStatus(ExcessStatus.FAILED);
        }
    }

    public void assign(WorkflowStatus workflowStatus){
        // HERE All FUNCTIONALITY OF ASSIGN OPERATION
        validate();
        switch (workflowStatus)
        {
            case ASSIGNED   -> setExcessStatus(ExcessStatus.ASSIGNED);
            case FAILED     -> setExcessStatus(ExcessStatus.FAILED);
        }
    }

    public MetricType getMetricType() {
        return metricType;
    }

    public ExcessMetric getExcessMetric() {
        return excessMetric;
    }

    public String getExcessBeginDate() { return excessBeginDate; }

    public String getExcessBeginTimestamp() { return excessBeginTimestamp; }

    public String getExcessEndDate() { return excessEndDate; }

    public String getExcessEndTimestamp() { return excessEndTimestamp; }

    public String getLimitInternalKey() {
        return limitInternalKey;
    }

    public ExcessType getExcessType() {
        return excessType;
    }

    public ExcessStatus getExcessStatus() {
        return excessStatus;
    }

    public ExcessDetail getExcessDetail() {return excessDetail;}

    public void setExcessType(ExcessType excessType) {
        this.excessType = excessType;
    }

    public void setExcessStatus(ExcessStatus excessStatus) {
        this.excessStatus = excessStatus;
    }

    public void setExcessDetail(ExcessDetail excessDetail) {
        this.excessDetail = excessDetail;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private ExcessId excessId;
        private MetricType metricType;
        private ExcessMetric excessMetric;
        private String excessBeginDate;
        private String excessBeginTimestamp;
        private String excessEndDate;
        private String excessEndTimestamp;
        private String limitInternalKey;
        private ExcessType excessType;
        private ExcessStatus excessStatus;
        private ExcessDetail excessDetail;

        private Builder() {
        }

        public Builder excessId(ExcessId val) {
            excessId = val;
            return this;
        }

        public Builder metricType(MetricType val) {
            metricType = val;
            return this;
        }

        public Builder excessMetric(ExcessMetric val) {
            excessMetric = val;
            return this;
        }

        public Builder excessBeginDate(String val) {
            excessBeginDate = val;
            return this;
        }

        public Builder excessBeginTimestamp(String val) {
            excessBeginTimestamp = val;
            return this;
        }

        public Builder excessEndDate(String val) {
            excessEndDate = val;
            return this;
        }

        public Builder excessEndTimestamp(String val) {
            excessEndTimestamp = val;
            return this;
        }

        public Builder limitInternalKey(String val) {
            limitInternalKey = val;
            return this;
        }

        public Builder excessType(ExcessType val) {
            excessType = val;
            return this;
        }

        public Builder excessStatus(ExcessStatus val) {
            excessStatus = val;
            return this;
        }

        public Builder excessDetail(ExcessDetail val) {
            excessDetail = val;
            return this;
        }

        public Excess build() {
            return new Excess(this);
        }
    }
}
