package com.santander.scib.creame.excesses.service.domain.application.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessType;
import com.santander.scib.creame.excesses.domain.valueobject.MetricType;
import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class ExcessRequest {

    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String excessId;

    @NotNull(message = "{not.null}")
    //@ValueOfEnum(enumClass = MetricType.class)
    @JsonProperty
    private MetricType metricType;

    @NotNull(message = "{not.null}")
    //@ValueOfEnum(enumClass = ExcessMetric.class)
    @JsonProperty
    private ExcessMetric excessMetric;

    @NotEmpty(message = "{not.empty}")
    @Size(min = 8, message = "{size.min}" + ": 8")
    @Size(max = 8, message = "{size.max}" + ": 8")
    @JsonProperty
    private String excessBeginDate;

    @NotEmpty(message = "{not.empty}")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    @JsonProperty
    private String excessBeginTimestamp;

    @Size(min = 8, message = "{size.min}" + ": 8")
    @Size(max = 8, message = "{size.max}" + ": 8")
    @JsonProperty
    private String excessEndDate;

    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    @JsonProperty
    private String excessEndTimestamp;

    @NotEmpty(message = "{not.empty}")
    @JsonProperty
    private String limitInternalKey;

    @JsonProperty
    //@ValueOfEnum(enumClass = ExcessType.class)
    private ExcessType excessType;

    @JsonProperty
    //@ValueOfEnum(enumClass = ExcessStatus.class)
    private ExcessStatus excessStatus;

    @NotNull(message = "{not.empty}")
    @JsonProperty
    private ExcessDetailDto excessDetail;
}
