package com.santander.scib.creame.excesses.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableJpaRepositories(basePackages = { "com.santander.scib.creame.excesses.application.outbox", "com.santander.scib.creame.excesses.service.adapters.dataaccess" })
@EntityScan(basePackages = { "com.santander.scib.creame.excesses.application.outbox", "com.santander.scib.creame.excesses.service.adapters.dataaccess"})
@SpringBootApplication(scanBasePackages = "com.santander.scib.creame.excesses")
@EnableAsync
public class ExcessServiceApplication {
    public static void main(String[] args) {
      SpringApplication.run(ExcessServiceApplication.class, args);
    }
}
