package com.santander.scib.creame.excesses.service.domain.application.ports.output.repository;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;

import java.util.Optional;

public interface ExcessRepository {
    Optional<Excess> findById(ExcessId excessId);
    Excess save(Excess excess);
    Excess update(Excess excess);
    void flush();
}
