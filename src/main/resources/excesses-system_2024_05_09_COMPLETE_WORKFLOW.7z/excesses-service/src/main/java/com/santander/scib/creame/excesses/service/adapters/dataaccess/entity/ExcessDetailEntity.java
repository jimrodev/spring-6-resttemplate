package com.santander.scib.creame.excesses.service.adapters.dataaccess.entity;

import com.google.common.base.Objects;

import com.santander.scib.creame.excesses.application.converter.HashMapConverter;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.domain.Persistable;

import java.math.BigDecimal;
import java.util.Map;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "excesses_history")
@Entity
@IdClass(ExcessDetailEntityId.class)
public class ExcessDetailEntity implements Persistable<String> {

    @Id
    private String excessId;
    @Id
    private String processTimestamp;
    private String processDate;
    private String limitOrigin;
    private String limitShortName;
    private String period;
    private String limitCurrency;
    private BigDecimal limitAmount;
    private BigDecimal used;
    private String excessReason;
    @Convert(converter = HashMapConverter.class)
    private Map<String, Object> metadata;

    @Transient
    private boolean isNew = true;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ExcessDetailEntity that = (ExcessDetailEntity) o;
        return Objects.equal(excessId, that.excessId) && Objects.equal(processTimestamp, that.processTimestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(excessId, processTimestamp);
    }

    @Override
    public String getId() {
        return null;
    }

    @Override
    public boolean isNew() {
        return this.isNew;
    }
}
