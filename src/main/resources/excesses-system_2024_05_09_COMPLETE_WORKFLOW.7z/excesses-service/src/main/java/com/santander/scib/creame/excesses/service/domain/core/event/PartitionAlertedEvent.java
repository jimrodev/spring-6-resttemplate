package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;

import java.time.ZonedDateTime;

public class PartitionAlertedEvent extends PartitionEvent {

    public PartitionAlertedEvent(Partition partition,
                                 ZonedDateTime createdAt) {
        super(partition, createdAt);
    }
}
