package com.santander.scib.creame.excesses.service.adapters.messaging.mapper;

import com.santander.scib.creame.avro.models.FilterRequestAvroModel;
import com.santander.scib.creame.avro.models.FilterResponseAvroModel;
import com.santander.scib.creame.excesses.domain.valueobject.FilterStatus;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.FilterResponse;
import org.springframework.stereotype.Component;

@Component
public class FilterMessagingDataMapper {
    public FilterResponse filterResponseAvroModelToFilterResponse(FilterResponseAvroModel filterResponseAvroModel) {
        return FilterResponse.builder()
                .filterId(filterResponseAvroModel.getFilterId())
                .excessId(filterResponseAvroModel.getExcessId())
                .processTimestamp(filterResponseAvroModel.getProcessTimestamp())
                .filterStatus(FilterStatus.valueOf(filterResponseAvroModel.getFilterStatus().name()))
                .filtersMatching(filterResponseAvroModel.getFiltersMatching())
                .build();
    }

    public FilterRequestAvroModel excessRequestToFilterRequestAvroModel(ExcessRequest excessRequest){

        return FilterRequestAvroModel.newBuilder()
                .setExcessId(excessRequest.getExcessId())
                .setProcessTimestamp(excessRequest.getExcessDetail().getProcessTimestamp())
                .build();
    }
}
