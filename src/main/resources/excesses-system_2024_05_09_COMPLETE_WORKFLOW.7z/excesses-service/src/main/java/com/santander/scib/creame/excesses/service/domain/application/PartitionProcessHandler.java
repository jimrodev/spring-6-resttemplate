package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.domain.valueobject.PartitionId;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.PartitionRepository;
import com.santander.scib.creame.excesses.service.domain.core.entity.Partition;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionAlertedEvent;
import com.santander.scib.creame.excesses.service.domain.core.event.PartitionEvent;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionResponse;
import com.santander.scib.creame.excesses.service.domain.application.mapper.PartitionDataMapper;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Slf4j
@Component
public class PartitionProcessHandler {

    private final PartitionProcessHelper partitionProcessHelper;
    private final PartitionDataMapper partitionDataMapper;

    private final PartitionRepository partitionRepository;

    public PartitionProcessHandler(PartitionProcessHelper partitionProcessHelper,
                                   PartitionDataMapper partitionDataMapper,
                                   PartitionRepository partitionRepository) {
        this.partitionProcessHelper = partitionProcessHelper;
        this.partitionDataMapper = partitionDataMapper;
        this.partitionRepository = partitionRepository;
    }

    @Transactional
    public PartitionResponse process(PartitionRequest partitionRequest, ContextMessage contextRequest){

        PartitionEvent partitionEvent = partitionProcessHelper.process(partitionRequest,
                                                                       contextRequest);

        log.info("Partition is processed with id: {}", partitionEvent.getEntity().getId().getValue());
        return partitionDataMapper.PartitionToPartitionResponse(partitionEvent.getEntity());
    }

    @Transactional
    public PartitionResponse reprocess(PartitionRequest partitionRequest, ContextMessage contextRequest) {

        PartitionEvent partitionEvent = partitionProcessHelper.reprocess(partitionRequest,
                                                                         contextRequest);

        log.info("Partition is reprocessed with id: {}", partitionEvent.getEntity().getId().getValue());
        return partitionDataMapper.PartitionToPartitionResponse(partitionEvent.getEntity());
    }

    @Transactional
    public PartitionResponse alert(PartitionRequest partitionRequest, ContextMessage contextRequest) {

        // REVIEW
        // LANZAR EVENTO AL MÓDULO DE ALERTAS

        PartitionAlertedEvent partitionEvent = partitionProcessHelper.alert(partitionRequest,
                                                                            contextRequest);

        log.info("Partition is alerted with id: {}", partitionEvent.getEntity().getId().getValue());
        return partitionDataMapper.PartitionToPartitionResponse(partitionEvent.getEntity());
    }

    public PartitionOperation computeOperation(PartitionRequest partitionRequest) {

        Optional<Partition> partitionFound = partitionRepository.findByPartitionId(
                                                new PartitionId(partitionRequest.getPartitionId()));

        // PROCESS (Partition does not exist - DB)
        if(partitionFound.isEmpty())
        {
            return PartitionOperation.PROCESS;
        }
        // REPROCESS (Partitions exist (DB) and force)
        else{
            Partition partition = partitionFound.get();

            if((partitionRequest.getForce() != null) && partitionRequest.getForce()){
                return PartitionOperation.REPROCESS;
            } else {

                // OTHER CASES - REVIEW !!
                // Partición es anterior a la última procesada

                // REVIEW !!
                return PartitionOperation.ALERT;
            }
        }
    }


}
