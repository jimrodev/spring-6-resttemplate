package com.santander.scib.creame.excesses.service.adapters.api.web.fn;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.application.validation.ValidationHandler;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessResponse;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest;
import com.santander.scib.creame.excesses.service.domain.application.dto.PartitionResponse;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.service.ExcessApplicationService;
import org.springframework.aot.hint.annotation.RegisterReflectionForBinding;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.validation.Validator;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

@Component
public class ExcessHandler {
    private final ExcessApplicationService excessApplicationService;

    private final ValidationHandler<ExcessRequest, Validator> excessValidator;
    private final ValidationHandler<PartitionRequest, Validator> partitionValidator;

    public ExcessHandler(ExcessApplicationService excessApplicationService,
                         @Qualifier("FunctionalEndPointValidator") Validator validator) {
        this.excessApplicationService = excessApplicationService;
        this.excessValidator = new ValidationHandler<ExcessRequest, Validator>(ExcessRequest.class, validator);
        this.partitionValidator = new ValidationHandler<PartitionRequest, Validator>(PartitionRequest.class, validator);
    }

    @RegisterReflectionForBinding(ExcessRequest.class)
    public Mono<ServerResponse> processExcess(final ServerRequest request){

        ContextMessage context = ContextMessage.builder()
                .messageType(ExcessRequest.class.getTypeName())   // FULL QUALIFIER ID: com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest
                .inboundTransportType("https://")
                .inboundTransportLocation(ExcessRouterConfig.EXCESS_PATH)
                .build();

        return request.bodyToMono(ExcessRequest.class)
                .doOnNext(this.excessValidator::validate)
                .flatMap(excessRequest ->  ServerResponse
                        .ok()
                        .header("location", UriComponentsBuilder.fromPath(ExcessRouterConfig.EXCESS_PATH_ID).build(excessRequest.getExcessId()).toString())
                        .body(Mono.just(excessApplicationService.processExcess(excessRequest, context)), ExcessResponse.class));
                        //.bodyValue(excessApplicationService.create(excessRequest)));
    }

    public Mono<ServerResponse> processPartition(final ServerRequest request){

        ContextMessage context = ContextMessage.builder()
                .messageType(PartitionRequest.class.getTypeName())   // FULL QUALIFIER ID: com.santander.scib.creame.excesses.service.domain.application.dto.PartitionRequest
                .inboundTransportType("https://")
                .inboundTransportLocation(ExcessRouterConfig.PARTITION_PATH)
                .build();

        return request.bodyToMono(PartitionRequest.class)
                .doOnNext(this.partitionValidator::validate)
                .flatMap(partitionRequest ->  ServerResponse
                        .ok()
                        .header("location", UriComponentsBuilder.fromPath(ExcessRouterConfig.PARTITION_PATH_ID).build(partitionRequest.getPartitionId()).toString())
                        .body(Mono.just(excessApplicationService.processPartition(partitionRequest, context)), PartitionResponse.class));
    }
}
