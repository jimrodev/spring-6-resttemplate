package com.santander.scib.creame.excesses.service.adapters.messaging.listener.kafka;

import com.santander.scib.creame.avro.models.ExcessRequestAvroModel;
import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumer;
import com.santander.scib.creame.excesses.infrastructure.kafka.KafkaConsumerHelper;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.ports.input.message.listener.ExcessRequestMessageListener;
import com.santander.scib.creame.excesses.service.adapters.messaging.mapper.ExcessMessagingDataMapper;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;


import java.util.List;

@Slf4j
@Component
public class ExcessRequestKafkaListener implements KafkaConsumer<ExcessRequestAvroModel> {

    private final ExcessRequestMessageListener excessRequestMessageListener;
    private final ExcessMessagingDataMapper excessMessagingDataMapper;
    private final String topicName;

    public ExcessRequestKafkaListener(ExcessRequestMessageListener excessRequestMessageListener,
                                      ExcessMessagingDataMapper excessMessagingDataMapper,
                                      @Value("#{@kafkaTopics['excesses-request']}") String topicName) {
        this.excessRequestMessageListener = excessRequestMessageListener;
        this.excessMessagingDataMapper = excessMessagingDataMapper;
        this.topicName = topicName;
    }

    @Override
    @KafkaListener(
            id = "excesses-listener",
            topics = "#{@kafkaTopics['excesses-request']}",
            containerFactory = "#{@kafkaListenerContainerFactories['excesses']}",
            idIsGroup = false
    )
    public void receivedBatch(List<Message<ExcessRequestAvroModel>> messages) {
        List<Message<ExcessRequestAvroModel>> sanitizedMessages = KafkaConsumerHelper.sanitizedMessages(messages);
        sanitizedMessages.forEach(excessRequestAvroModelMessage -> {
            try {
                ContextMessage context = ContextMessage.builder()
                        .messageId(excessRequestAvroModelMessage.getPayload().getExcessId())
                        .messageType(ExcessRequest.class.getTypeName())   // FULL QUALIFIER ID: com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest
                        .inboundTransportType("kafka://")
                        .inboundTransportLocation(topicName)
                        .build();

                excessRequestMessageListener.process(
                        excessMessagingDataMapper.excessRequestAvroModelToExcessRequest(
                                excessRequestAvroModelMessage.getPayload()
                        ),
                        context
                );
            } catch (OptimisticLockingFailureException e) {
                //NO-OP for optimistic lock. This means another thread finished the work, do not throw error to prevent reading the data from kafka again!
                log.error("Caught optimistic locking exception in ExcessRequestKafkaListener for excess id: {}",
                        excessRequestAvroModelMessage.getPayload().getExcessId());
            }
        });
    }
}