package com.santander.scib.creame.excesses.service.domain.application.dto;

import com.santander.scib.creame.excesses.domain.valueobject.ExcessMetric;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessStatus;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessType;
import com.santander.scib.creame.excesses.domain.valueobject.MetricType;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;


// HE PUSTO LA MISMA SALIDA QUE LA ENTRADA PERO HABRÁ QUE VER QUE SE DEVUELVE EN CADA CASO
@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
@Builder
public class ExcessResponse {
    @NotEmpty(message = "{not.empty}")
    @Size(max = 25, message = "{size.max}" + ": 25")
    private String excessId;

    @NotNull(message = "{not.null}")
    //@ValueOfEnum(enumClass = MetricType.class)
    private MetricType metricType;

    @NotNull(message = "{not.null}")
    //@ValueOfEnum(enumClass = ExcessMetric.class)
    private ExcessMetric excessMetric;

    @NotEmpty(message = "{not.empty}")
    @Size(min = 8, message = "{size.min}" + ": 8")
    @Size(max = 8, message = "{size.max}" + ": 8")
    private String excessBeginDate;

    @NotEmpty(message = "{not.empty}")
    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    private String excessBeginTimestamp;

    @Size(min = 8, message = "{size.min}" + ": 8")
    @Size(max = 8, message = "{size.max}" + ": 8")
    private String excessEndDate;

    @Size(min = 16, message = "{size.min}" + ": 16")
    @Size(max = 16, message = "{size.max}" + ": 16")
    private String excessEndTimestamp;

    @NotEmpty(message = "{not.empty}")
    private String limitInternalKey;

    private ExcessType excessType;

    private ExcessStatus excessStatus;

    @NotNull(message = "{not.null}")
    private ExcessDetailDto excessDetail;
}