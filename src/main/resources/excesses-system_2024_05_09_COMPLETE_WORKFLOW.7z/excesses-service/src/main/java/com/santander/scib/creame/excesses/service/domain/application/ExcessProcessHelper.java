package com.santander.scib.creame.excesses.service.domain.application;

import com.santander.scib.creame.excesses.application.outbox.dto.ContextMessage;
import com.santander.scib.creame.excesses.domain.valueobject.ExcessId;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessRepository;
import com.santander.scib.creame.excesses.service.domain.application.dto.ExcessRequest;
import com.santander.scib.creame.excesses.service.domain.application.mapper.ExcessDataMapper;
import com.santander.scib.creame.excesses.service.domain.application.ports.output.repository.ExcessDetailRepository;
import com.santander.scib.creame.excesses.service.domain.core.ExcessDomainService;
import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;
import com.santander.scib.creame.excesses.service.domain.core.entity.ExcessDetail;
import com.santander.scib.creame.excesses.service.domain.core.event.*;
import com.santander.scib.creame.excesses.service.domain.core.exception.ExcessDomainException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Optional;

import static com.santander.scib.creame.excesses.domain.DomainConstants.UTC;

@Slf4j
@Component
public class ExcessProcessHelper {

    private final ExcessDomainService excessesDomainService;
    private final ExcessRepository excessRepository;
    private final ExcessDetailRepository excessDetailRepository;
    private final ExcessDataMapper excessDataMapper;

    public ExcessProcessHelper(ExcessDomainService excessesDomainService,
                               ExcessRepository excessRepository,
                               ExcessDetailRepository excessDetailRepository,
                               ExcessDataMapper excessDataMapper) {
        this.excessesDomainService = excessesDomainService;
        this.excessRepository = excessRepository;
        this.excessDetailRepository = excessDetailRepository;
        this.excessDataMapper = excessDataMapper;
    }

    @Transactional
    public ExcessCreatedEvent persistExcess(ExcessRequest excessRequest){

        Excess excess = excessDataMapper.ExcessRequestToExcess(excessRequest);
        ExcessCreatedEvent excessCreatedEvent = excessesDomainService.create(excess);
        save(excess);
        return excessCreatedEvent;
    }

    @Transactional
    public ExcessUpdatedEvent updateExcess(ExcessRequest excessRequest){

        Excess excess = excessDataMapper.ExcessRequestToExcess(excessRequest);
        ExcessUpdatedEvent excessUpdatedEvent = excessesDomainService.update(excess);
        update(excess);
        return excessUpdatedEvent;
    }

    @Transactional
    public ExcessResolvedEvent solveExcess(ExcessRequest excessRequest){

        Excess excess = excessDataMapper.ExcessRequestToExcess(excessRequest);
        ExcessResolvedEvent excessResolvedEvent = excessesDomainService.solve(excess);
        update(excess);
        return excessResolvedEvent;
    }

    @Transactional
    public ExcessAlertedEvent alertExcess(ExcessRequest excessRequest, ContextMessage context) {

        // ALERT
        // REVIEW CREAR UN EVENTO QUE VAYA AL MODULO DE ALERTAS?
        // CREAR UN ESTADO QUE INDIQUE QUE SE HA PRODUCIDO LA ALERTA?
        Excess excess = excessDataMapper.ExcessRequestToExcess(excessRequest);
        return new ExcessAlertedEvent(excess,
                ZonedDateTime.now(ZoneId.of(UTC)));

    }

    private Excess save(Excess excess) {

        Excess excessResult = excessRepository.save(excess);
        if (excessResult == null) {
            log.error("Could not save excess!");
            throw new ExcessDomainException("Could not save excess!");
        }
        log.info("Excess is saved with id: {}", excessResult.getId().getValue());
        ExcessDetail excessDetailResult = excessDetailRepository.save(excess.getExcessDetail());
        excessResult.setExcessDetail(excessDetailResult);
        return  excessResult;
    }

    private Excess update(Excess excess) {

        Excess excessResult = excessRepository.update(excess);
        if (excessResult == null) {
            log.error("Could not update excess!");
            throw new ExcessDomainException("Could not save excess!");
        }
        log.info("Excess is updated with id: {}", excessResult.getId().getValue());
        ExcessDetail excessDetailResult = excessDetailRepository.update(excess.getExcessDetail());
        excessResult.setExcessDetail(excessDetailResult);
        return  excessResult;
    }

    @Transactional(readOnly = true)
    public Optional<Excess> findById(ExcessId excessId){

        return excessRepository.findById(excessId);
    }
}
