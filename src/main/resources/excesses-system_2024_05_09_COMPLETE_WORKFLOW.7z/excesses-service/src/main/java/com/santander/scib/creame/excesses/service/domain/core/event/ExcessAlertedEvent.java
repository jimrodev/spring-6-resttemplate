package com.santander.scib.creame.excesses.service.domain.core.event;

import com.santander.scib.creame.excesses.service.domain.core.entity.Excess;

import java.time.ZonedDateTime;

public class ExcessAlertedEvent extends ExcessEvent {

    public ExcessAlertedEvent(Excess excess,
                              ZonedDateTime createdAt) {
        super(excess, createdAt);
    }
}
